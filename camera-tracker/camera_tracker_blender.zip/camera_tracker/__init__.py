"""Camera Tracker for Blender: imports a take recorded with the Camera Tracker
Android app (video + ARCore camera path) as a ready matched camera.

The phone writes ARCore's world: metres, +Y up, the camera looking down its -Z
with +Y up in the picture, which is already Blender's camera convention. So the
whole take lives under one root empty that turns Y up into Z up, and moving,
turning or scaling that root lines the take up with any scene.
"""

bl_info = {
    "name": "Camera Tracker",
    "author": "Akshay C P",
    "version": (1, 15, 0),
    "blender": (4, 2, 0),
    "location": "File > Import > Camera Tracker take, and the Tracker tab in the 3D view sidebar",
    "description": "Import phone camera tracks from the Camera Tracker Android app",
    "category": "Import-Export",
}

import json
import math
import os
import zipfile

import bpy
from bpy.props import BoolProperty, FloatProperty, FloatVectorProperty, IntProperty, StringProperty
from bpy_extras.io_utils import ImportHelper
from mathutils import Matrix, Quaternion, Vector

ROOT_KEY = "camtrack_root"


# --------------------------------------------------------------------- reading

def _find_track(path):
    """Returns the track.json for a zip, a folder or the json itself."""
    path = bpy.path.abspath(path)
    if path.lower().endswith(".zip"):
        base = os.path.splitext(path)[0]
        with zipfile.ZipFile(path) as z:
            names = [n for n in z.namelist() if n.endswith("track.json")]
            if not names:
                raise ValueError("That zip has no track.json in it")
            # Unpack next to the zip so the video stays where the .blend can find it.
            target = os.path.dirname(path)
            top = names[0].split("/")[0] if "/" in names[0] else None
            if top is None:
                target = base
            z.extractall(target)
            return os.path.join(target, names[0])
    if os.path.isdir(path):
        path = os.path.join(path, "track.json")
    if not os.path.exists(path):
        raise ValueError("No track.json found")
    return path


def _load(path):
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    if data.get("format") != "camera-tracker":
        raise ValueError("This is not a Camera Tracker take")
    return data


def _pose_matrix(p):
    """[px, py, pz, qx, qy, qz, qw] in ARCore order to a 4x4."""
    q = Quaternion((p[6], p[3], p[4], p[5]))
    m = q.to_matrix().to_4x4()
    m.translation = Vector((p[0], p[1], p[2]))
    return m


# ------------------------------------------------------------------ animation

def _fcurves(obj):
    """All F-curves of an object's action, on both the 5.x slotted API and the old one."""
    ad = obj.animation_data
    if ad is None or ad.action is None:
        return []
    action = ad.action
    slot = getattr(ad, "action_slot", None)
    if slot is not None:
        try:
            from bpy_extras import anim_utils
            bag = anim_utils.action_get_channelbag_for_slot(action, slot)
            if bag is not None:
                return list(bag.fcurves)
        except (ImportError, AttributeError):
            pass
    return list(getattr(action, "fcurves", []))


def _bake(obj, path, values_per_frame, start):
    """Writes one key per frame for every channel of `path` in a single pass.

    values_per_frame is a list of tuples (one tuple per frame)."""
    n = len(values_per_frame)
    if n == 0:
        return
    width = len(values_per_frame[0])
    obj.keyframe_insert(path, frame=start)
    curves = {fc.array_index: fc for fc in _fcurves(obj) if fc.data_path == path}
    for i in range(width):
        fc = curves.get(i)
        if fc is None:
            continue
        fc.keyframe_points.clear()
        fc.keyframe_points.add(n)
        co = [0.0] * (2 * n)
        for f in range(n):
            co[2 * f] = start + f
            co[2 * f + 1] = values_per_frame[f][i]
        fc.keyframe_points.foreach_set("co", co)
        fc.keyframe_points.foreach_set("interpolation", [1] * n)  # LINEAR
        fc.update()


def _smoothed(poses, ok, window):
    """Centred moving average on positions, normalised average on rotations.

    Frames where tracking was lost hold the last good pose instead."""
    n = len(poses)
    good = list(poses)
    last = None
    for i in range(n):
        if ok[i]:
            last = poses[i]
        elif last is not None:
            good[i] = last
    if window <= 0:
        return good
    out = []
    for i in range(n):
        a, b = max(0, i - window), min(n, i + window + 1)
        loc = Vector()
        q0 = Quaternion((good[i][6], good[i][3], good[i][4], good[i][5]))
        qs = Vector((0, 0, 0, 0))
        for j in range(a, b):
            p = good[j]
            loc += Vector(p[:3])
            q = Quaternion((p[6], p[3], p[4], p[5]))
            if q.dot(q0) < 0:
                q.negate()
            qs += Vector(q)
        loc /= (b - a)
        q = Quaternion(qs).normalized()
        out.append([loc.x, loc.y, loc.z, q.x, q.y, q.z, q.w])
    return out


def _key_camera(cam_obj, data, smoothing, offset):
    frames = data["frames"]
    poses = [f[2:9] for f in frames]
    ok = [bool(f[1]) for f in frames]
    poses = _smoothed(poses, ok, smoothing)

    locs, quats = [], []
    prev = None
    for p in poses:
        q = Quaternion((p[6], p[3], p[4], p[5]))
        # Keep neighbouring quaternions on the same side so interpolation never spins.
        if prev is not None and q.dot(prev) < 0:
            q.negate()
        prev = q
        locs.append((p[0], p[1], p[2]))
        quats.append((q.w, q.x, q.y, q.z))

    if cam_obj.animation_data:
        cam_obj.animation_data_clear()
    cam_obj.rotation_mode = "QUATERNION"
    start = 1 + offset
    _bake(cam_obj, "location", locs, start)
    _bake(cam_obj, "rotation_quaternion", quats, start)

    # Lens: one row unless the focus moved.
    cam = cam_obj.data
    if cam.animation_data:
        cam.animation_data_clear()
    lens_rows = data.get("lens") or []
    w, h = data["width"], data["height"]
    big = max(w, h)
    cam.sensor_fit = "AUTO"
    cam.sensor_width = 36.0
    for row in lens_rows:
        frame, fx, fy, cx, cy = row
        f_big = fx if w >= h else fy
        cam.lens = f_big * cam.sensor_width / big
        # Blender shifts the frame in units of its longer side.
        cam.shift_x = (w / 2.0 - cx) / big
        cam.shift_y = (cy - h / 2.0) / big
        if len(lens_rows) > 1:
            cam.keyframe_insert("lens", frame=start + int(frame))
            cam.keyframe_insert("shift_x", frame=start + int(frame))
            cam.keyframe_insert("shift_y", frame=start + int(frame))


# --------------------------------------------------------------- scene build

def _collection(name, parent):
    col = bpy.data.collections.new(name)
    parent.children.link(col)
    return col


def _link(obj, col):
    col.objects.link(obj)
    return obj


def _plane_mesh(name, polygon):
    """An ARCore plane polygon is (x, z) pairs in the plane's own space, y = 0."""
    verts = [(polygon[i], 0.0, polygon[i + 1]) for i in range(0, len(polygon) - 1, 2)]
    mesh = bpy.data.meshes.new(name)
    if len(verts) >= 3:
        mesh.from_pydata(verts, [], [list(range(len(verts)))])
    mesh.update()
    return mesh


def _main_floor(data):
    floors = [p for p in data.get("planes", []) if p["type"] == "floor"]
    if not floors:
        return None
    # The biggest plane is not always the floor you filmed: ground past a terrace
    # wall can be just as big and 65 cm lower. The filmed floor is the one most
    # tracked points lie on; size only breaks ties.
    ys = [p[1] for p in _points(data)]

    def support(p):
        y = p["pose"][1]
        return sum(1 for v in ys if abs(v - y) < 0.05)

    return max(floors, key=lambda p: (support(p), p["extent"][0] * p["extent"][1]))


def _points(data):
    """Feature points as (x, y, z), without the (0, 0, 0) ones ARCore hands out before it tracks."""
    pts = data.get("points") or []
    out = []
    for i in range(0, len(pts) - 2, 3):
        p = (pts[i], pts[i + 1], pts[i + 2])
        if p != (0, 0, 0):
            out.append(p)
    return out


def build_take(context, track_path, floor_to_zero=True, marker_origin=True, point_cloud=True):
    data = _load(track_path)
    folder = os.path.dirname(track_path)
    name = os.path.basename(folder) or "Take"
    scene = context.scene
    n = len(data["frames"])
    w, h, fps = data["width"], data["height"], data["fps"]

    scene.render.resolution_x = w
    scene.render.resolution_y = h
    scene.render.resolution_percentage = 100
    scene.render.fps = int(fps)
    scene.render.fps_base = 1.0
    scene.frame_start = 1
    scene.frame_end = n
    scene.frame_set(1)

    col = _collection(name, scene.collection)

    # The root: ARCore's Y up turned into Blender's Z up.
    root = _link(bpy.data.objects.new(name + " origin", None), col)
    root.empty_display_type = "ARROWS"
    root.empty_display_size = 0.25
    root[ROOT_KEY] = bpy.path.relpath(track_path) if bpy.data.filepath else track_path
    root.rotation_euler = (math.radians(90), 0, 0)

    def child(obj):
        _link(obj, col)
        obj.parent = root
        return obj

    # Camera.
    cam_data = bpy.data.cameras.new(name + " camera")
    cam_data.clip_start = 0.02
    cam_data.clip_end = 500
    cam = child(bpy.data.objects.new(name + " camera", cam_data))
    cam["camtrack_smoothing"] = 0
    cam["camtrack_offset"] = 0
    _key_camera(cam, data, 0, 0)
    scene.camera = cam

    # The plate behind the camera.
    video = os.path.join(folder, data.get("video", "shot.mp4"))
    if os.path.exists(video):
        clip = bpy.data.movieclips.load(video, check_existing=True)
        clip.frame_start = 1
        scene.active_clip = clip
        cam_data.show_background_images = True
        bg = cam_data.background_images.new()
        bg.source = "MOVIE_CLIP"
        bg.clip = clip
        bg.alpha = 1.0
        bg.display_depth = "BACK"
        if hasattr(bg, "use_camera_clip"):
            bg.use_camera_clip = False

    # Markers the user tapped on the phone.
    markers = []
    for m in data.get("markers", []):
        e = child(bpy.data.objects.new(m["name"], None))
        e.empty_display_type = "PLAIN_AXES"
        e.empty_display_size = 0.08
        e.matrix_parent_inverse = Matrix.Identity(4)
        e.matrix_basis = _pose_matrix(m["pose"])
        markers.append(e)

    # Surfaces ARCore found are not added as objects: the floor height and the
    # shadow catcher read them straight from the track.

    # Feature points, handy to see where real surfaces were.
    verts = _points(data)
    if point_cloud and verts:
        mesh = bpy.data.meshes.new(name + " points")
        mesh.from_pydata(verts, [], [])
        o = child(bpy.data.objects.new(name + " points", mesh))
        o.hide_render = True

    # Put the scene's origin somewhere useful: the first marker, else the floor.
    # Across from the first marker (else the floor's middle), height from the floor
    # (else that marker), so a marker tapped on a table still leaves the floor at 0.
    floor = _main_floor(data)
    first = Vector(data["markers"][0]["pose"][:3]) if data.get("markers") else None
    anchor = Vector((0.0, 0.0, 0.0))
    if marker_origin and first is not None:
        anchor.x, anchor.z = first.x, first.z
    elif floor:
        anchor.x, anchor.z = floor["pose"][0], floor["pose"][2]
    if floor_to_zero and floor:
        anchor.y = floor["pose"][1]
    elif first is not None and marker_origin:
        anchor.y = first.y
    # ARCore (x, y, z) lands at Blender (x, -z, y) under the root.
    root.location = (-anchor.x, anchor.z, -anchor.y)
    root["camtrack_floor_y"] = floor["pose"][1] if floor else anchor.y

    for o in context.view_layer.objects:
        o.select_set(False)
    root.select_set(True)
    context.view_layer.objects.active = root
    return root


def _root_of(obj):
    while obj is not None:
        if ROOT_KEY in obj:
            return obj
        obj = obj.parent
    return None


def _active_root(context):
    root = _root_of(context.active_object)
    if root:
        return root
    cam = context.scene.camera
    return _root_of(cam)


def _take_camera(root):
    for c in root.children:
        if c.type == "CAMERA":
            return c
    return None


# ------------------------------------------------------------------ operators

class CAMTRACK_OT_import(bpy.types.Operator, ImportHelper):
    """Import a take from the Camera Tracker phone app (zip or track.json)"""
    bl_idname = "camtrack.import_take"
    bl_label = "Import Camera Tracker take"
    bl_options = {"REGISTER", "UNDO"}

    filter_glob: StringProperty(default="*.zip;*.json", options={"HIDDEN"})
    floor_to_zero: BoolProperty(name="Floor at Z = 0", default=True,
                                description="Move the take so the floor the phone found sits at Z = 0")
    marker_origin: BoolProperty(name="Marker 1 is the origin", default=True,
                                description="Put the first marker you tapped at the world origin")
    point_cloud: BoolProperty(name="Feature points", default=True,
                              description="Add the points the phone tracked, as a reference mesh")
    new_scene: BoolProperty(name="Open in a new VFX scene", default=True,
                            description="Import into a clean scene of its own, leaving the default cube, camera and light behind")
    setup: BoolProperty(name="Set up the scene too", default=True,
                        description="Render settings, shadows, lighting and composite, all in one go")

    def execute(self, context):
        try:
            track = _find_track(self.filepath)
            if self.new_scene:
                shot = os.path.basename(os.path.dirname(track)) or "Shot"
                scene = bpy.data.scenes.new("VFX " + shot)
                if context.window is not None:
                    context.window.scene = scene
                with context.temp_override(scene=scene, view_layer=scene.view_layers[0]):
                    build_take(bpy.context, track, self.floor_to_zero, self.marker_origin, self.point_cloud)
                    if self.setup:
                        bpy.ops.camtrack.setup()
            else:
                build_take(context, track, self.floor_to_zero, self.marker_origin, self.point_cloud)
                if self.setup:
                    bpy.ops.camtrack.setup()
        except Exception as e:
            self.report({"ERROR"}, str(e))
            return {"CANCELLED"}
        self.report({"INFO"}, "Take imported. Press Numpad 0 to look through the phone")
        return {"FINISHED"}


class CAMTRACK_OT_rekey(bpy.types.Operator):
    """Re-bake the camera with smoothing and a frame offset, from the original track"""
    bl_idname = "camtrack.rekey"
    bl_label = "Apply"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        root = _active_root(context)
        cam = _take_camera(root) if root else None
        if cam is None:
            self.report({"ERROR"}, "Select something from an imported take first")
            return {"CANCELLED"}
        path = bpy.path.abspath(root[ROOT_KEY])
        try:
            data = _load(path)
        except Exception as e:
            self.report({"ERROR"}, f"Can't read the track again: {e}")
            return {"CANCELLED"}
        _key_camera(cam, data, int(cam.get("camtrack_smoothing", 0)), int(cam.get("camtrack_offset", 0)))
        return {"FINISHED"}


class CAMTRACK_OT_shadow_catcher(bpy.types.Operator):
    """Add a shadow catcher on the floor so objects cast shadows onto the real ground"""
    bl_idname = "camtrack.shadow_catcher"
    bl_label = "Add shadow catcher"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        root = _active_root(context)
        if root is None:
            self.report({"ERROR"}, "Select something from an imported take first")
            return {"CANCELLED"}
        data = _load(bpy.path.abspath(root[ROOT_KEY]))
        floor = _main_floor(data)
        size = 6.0
        if floor:
            size = max(4.0, 2.5 * max(floor["extent"]))
            y = floor["pose"][1]
            centre = Vector((floor["pose"][0], y, floor["pose"][2]))
        else:
            y = root.get("camtrack_floor_y", 0.0)
            centre = Vector((0.0, y, 0.0))
        for old in [c for c in root.children if c.name.startswith("Shadow catcher")]:
            bpy.data.objects.remove(old)
        bpy.ops.mesh.primitive_plane_add(size=size)
        plane = context.active_object
        plane.name = "Shadow catcher"
        for c in plane.users_collection:
            c.objects.unlink(plane)
        root.users_collection[0].objects.link(plane)
        plane.parent = root
        # A plane is made flat in XY; in the root's Y up space the floor is XZ.
        plane.matrix_basis = Matrix.Translation(centre) @ Matrix.Rotation(math.radians(-90), 4, "X")
        _make_catcher(plane, _catcher_material(_estimate_lit(context.scene), context.scene))
        if context.scene.render.engine not in {"CYCLES", _eevee_id()}:
            context.scene.render.engine = "CYCLES"
        context.scene.render.film_transparent = True
        self.report({"INFO"}, "Shadow catcher added. Use Set up composite to render over the video")
        return {"FINISHED"}


def _compositor_tree(scene):
    """The compositing node tree on 5.x (a node group) and on 4.x (scene.node_tree)."""
    if hasattr(scene, "compositing_node_group"):
        tree = scene.compositing_node_group
        if tree is None:
            tree = bpy.data.node_groups.new("Camera Tracker composite", "CompositorNodeTree")
            scene.compositing_node_group = tree
        return tree, True
    scene.use_nodes = True
    return scene.node_tree, False


class CAMTRACK_OT_composite(bpy.types.Operator):
    """Render the 3D layer over the phone video, with shadows, in one click"""
    bl_idname = "camtrack.composite"
    bl_label = "Set up composite"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene = context.scene
        clip = scene.active_clip
        if clip is None:
            self.report({"ERROR"}, "No video found. Import a take first")
            return {"CANCELLED"}
        scene.render.film_transparent = True
        if scene.render.engine not in {"CYCLES", "BLENDER_EEVEE_NEXT", "BLENDER_EEVEE"}:  # Workbench can't do this
            scene.render.engine = "CYCLES"
        tree, is_group = _compositor_tree(scene)
        tree.nodes.clear()
        rl = tree.nodes.new("CompositorNodeRLayers")
        rl.location = (-300, 200)
        mc = tree.nodes.new("CompositorNodeMovieClip")
        mc.clip = clip
        mc.location = (-300, -150)
        over = tree.nodes.new("CompositorNodeAlphaOver")
        over.location = (50, 50)
        # Background goes in the first image socket, the render on top in the second.
        image_inputs = [s for s in over.inputs if s.type == "RGBA"]
        # Fit the plate to the render size, so a 50% preview render still lines up.
        fit = tree.nodes.new("CompositorNodeScale")
        fit.location = (-120, -150)
        if "Type" in fit.inputs:  # 5.x: options are menu sockets
            try:
                fit.inputs["Type"].default_value = "Render Size"
                fit.inputs["Frame Type"].default_value = "Fit"
            except (TypeError, KeyError):
                pass
        else:
            fit.space = "RENDER_SIZE"
            fit.frame_method = "FIT"
        tree.links.new(mc.outputs["Image"], fit.inputs[0])
        tree.links.new(fit.outputs[0], image_inputs[0])
        tree.links.new(rl.outputs["Image"], image_inputs[1])
        if is_group:
            if not any(s.in_out == "OUTPUT" for s in tree.interface.items_tree if getattr(s, "item_type", "") == "SOCKET"):
                tree.interface.new_socket("Image", in_out="OUTPUT", socket_type="NodeSocketColor")
            out = tree.nodes.new("NodeGroupOutput")
            out.location = (300, 50)
            tree.links.new(over.outputs[0], out.inputs[0])
        else:
            out = tree.nodes.new("CompositorNodeComposite")
            out.location = (300, 50)
            tree.links.new(over.outputs[0], out.inputs[0])
        viewer = tree.nodes.new("CompositorNodeViewer")
        viewer.location = (300, -150)
        tree.links.new(over.outputs[0], viewer.inputs[0])
        self.report({"INFO"}, "Composite ready. F12 renders your objects over the video")
        return {"FINISHED"}


class CAMTRACK_OT_match_light(bpy.types.Operator):
    """Add a sun pointing the way the real main light came from, as the phone measured it"""
    bl_idname = "camtrack.match_light"
    bl_label = "Match the real light"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        root = _active_root(context)
        if root is None:
            self.report({"ERROR"}, "Select something from an imported take first")
            return {"CANCELLED"}
        data = _load(bpy.path.abspath(root[ROOT_KEY]))
        light = data.get("light")
        if not light:
            self.report({"WARNING"}, "This phone did not measure the light for this take")
            return {"CANCELLED"}
        d = Vector(light["direction"]).normalized()
        c = Vector(light["intensity"])
        peak = max(c.x, c.y, c.z, 1e-4)
        for old in [c for c in root.children if c.name.startswith("Real light")]:
            bpy.data.objects.remove(old)
        sun_data = bpy.data.lights.new("Real light", "SUN")
        sun_data.color = (c.x / peak, c.y / peak, c.z / peak)
        sun_data.energy = max(0.5, min(10.0, peak * 3.0))
        sun_data.angle = math.radians(8)
        sun = bpy.data.objects.new("Real light", sun_data)
        root.users_collection[0].objects.link(sun)
        sun.parent = root
        # A sun shines down its -Z; ARCore's direction points towards the light.
        sun.matrix_basis = d.to_track_quat("Z", "Y").to_matrix().to_4x4()
        sun.location = Vector((0, 1.5, 0))

        sh = light.get("harmonics")
        if sh and len(sh) >= 3:
            world = context.scene.world or bpy.data.worlds.new("World")
            context.scene.world = world
            ambient = [max(0.0, v * 0.886) for v in sh[:3]]
            if hasattr(world, "use_nodes"):
                world.use_nodes = True
            bg = next((n for n in world.node_tree.nodes if n.type == "BACKGROUND"), None) if world.node_tree else None
            if bg:
                bg.inputs["Color"].default_value = (*ambient, 1.0)
                bg.inputs["Strength"].default_value = 1.0
            else:
                world.color = ambient
        self.report({"INFO"}, "Sun added from the light the phone saw")
        return {"FINISHED"}


class CAMTRACK_OT_to_marker(bpy.types.Operator):
    """Stand the selected objects on a marker you tapped on the phone"""
    bl_idname = "camtrack.to_marker"
    bl_label = "Put selection on marker"
    bl_options = {"REGISTER", "UNDO"}

    marker: StringProperty()

    def execute(self, context):
        target = bpy.data.objects.get(self.marker)
        if target is None:
            return {"CANCELLED"}
        spot = target.matrix_world.translation.copy()
        moved = 0
        for o in context.selected_objects:
            if o == target or _root_of(o) is not None:
                continue
            o.location = spot if o.parent is None else o.parent.matrix_world.inverted() @ spot
            moved += 1
        if moved == 0:
            self.report({"WARNING"}, "Select your own objects first, then pick the marker")
        return {"FINISHED"}


def _filmed_ambient(folder, room):
    """Median linear colour of what the camera filmed, from the colour snapshots."""
    import numpy as np
    vals = []
    for i in range(len(room.get("keyframes") or [])):
        path = os.path.join(folder, "room", "c_%03d.jpg" % i)
        if not os.path.exists(path):
            continue
        img = bpy.data.images.load(path, check_existing=False)
        px = np.empty(img.size[0] * img.size[1] * 4, np.float32)
        img.pixels.foreach_get(px)  # Blender hands these back already linear
        bpy.data.images.remove(img)
        vals.append(px.reshape(-1, 4)[::7, :3])
    if not vals:
        return (0.25, 0.25, 0.25)
    m = np.median(np.concatenate(vals), axis=0)
    return tuple(float(x) for x in m)


class CAMTRACK_OT_room_light(bpy.types.Operator):
    """Light the scene with the HDRI: the one you captured on the phone, or a rough one made while filming"""
    bl_idname = "camtrack.room_light"
    bl_label = "Light with the HDRI"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        root = _active_root(context)
        if root is None:
            self.report({"ERROR"}, "Select something from an imported take first")
            return {"CANCELLED"}
        track = bpy.path.abspath(root[ROOT_KEY])
        data = _load(track)
        room = data.get("room") or {}
        hdr = os.path.join(os.path.dirname(track), room.get("hdr", "env.hdr"))
        if not os.path.exists(hdr):
            self.report({"WARNING"}, "This shot has no HDRI. Record it again with app 1.0.1 or newer")
            return {"CANCELLED"}
        scene = context.scene
        world = bpy.data.worlds.new(root.name.replace(" origin", "") + " room")
        scene.world = world
        if hasattr(world, "use_nodes"):
            world.use_nodes = True
        nt = world.node_tree
        bg = next(n for n in nt.nodes if n.type == "BACKGROUND")
        env = nt.nodes.new("ShaderNodeTexEnvironment")
        env.image = bpy.data.images.load(hdr, check_existing=True)
        env.location = (-300, 300)
        # The HDR is laid out for an unturned take; follow the take if it was spun round Z.
        coord = nt.nodes.new("ShaderNodeTexCoord")
        coord.location = (-700, 300)
        mapping = nt.nodes.new("ShaderNodeMapping")
        mapping.location = (-500, 300)
        # App 1.0.1 laid the HDR out half a turn round from Blender's convention.
        half_turn = 0.0 if room.get("layout") == "blender" else math.pi
        mapping.inputs["Rotation"].default_value[2] = half_turn - root.rotation_euler[2]
        nt.links.new(coord.outputs["Generated"], mapping.inputs["Vector"])
        nt.links.new(mapping.outputs["Vector"], env.inputs["Vector"])
        # A captured HDRI (env.json says so) is the real thing: real lamps or sun, full
        # sphere, real exposure range. The rough one needs lifting and a key light.
        env_info = {}
        env_json = os.path.join(os.path.dirname(track), "env.json")
        if os.path.exists(env_json):
            with open(env_json, "r", encoding="utf-8") as f:
                env_info = json.load(f)
        captured = env_info.get("source") == "hdri"
        if captured:
            half_turn = 0.0
            mapping.inputs["Rotation"].default_value[2] = -root.rotation_euler[2]
        ambient = _filmed_ambient(os.path.dirname(track), room)
        if captured:
            ambient = tuple(c * 0.25 for c in ambient)  # only patches gaps the capture missed
        lift = nt.nodes.new("ShaderNodeMix")
        lift.data_type = "RGBA"
        lift.blend_type = "LIGHTEN"
        lift.inputs["Factor"].default_value = 1.0
        lift.location = (-60, 300)
        lift.inputs[6].default_value = (*[c * 0.8 for c in ambient], 1.0)
        nt.links.new(env.outputs["Color"], lift.inputs[7])
        nt.links.new(lift.outputs[2], bg.inputs["Color"])
        bg.inputs["Strength"].default_value = 1.0
        if hasattr(world, "sun_threshold"):
            # Rough HDR: the key light below casts the shadows, so no second sun from it.
            # Captured HDRI: let EEVEE pull the real lamp or sun out as a shadow casting light.
            world.sun_threshold = 2.0 if captured else 1000.0

        # A key light along the main light the phone measured, strong enough next to
        # the room light for a clear shadow (a white floor shows E * cos / pi).
        for c in [c for c in root.children if c.type == "LIGHT" and c.name.startswith("Real light")]:
            bpy.data.objects.remove(c)
        light = None if captured else data.get("light")
        if light:
            d = Vector(light["direction"]).normalized()
            amb = sum(ambient) / 3.0
            up = max(0.25, d.y)  # ARCore's +Y is up; a grazing light still gets some strength
            sun_data = bpy.data.lights.new("Real light", "SUN")
            sun_data.energy = max(0.2, 1.5 * amb * math.pi / up)
            sun_data.angle = math.radians(6)
            c = Vector(light["intensity"])
            peak = max(c.x, c.y, c.z, 1e-4)
            sun_data.color = (c.x / peak, c.y / peak, c.z / peak)
            sun = bpy.data.objects.new("Real light", sun_data)
            root.users_collection[0].objects.link(sun)
            sun.parent = root
            sun.matrix_basis = d.to_track_quat("Z", "Y").to_matrix().to_4x4()
            sun.location = Vector((0, 1.5, 0))
        if scene.render.engine == _eevee_id() and _find_catcher(scene):
            _calibrate_eevee(scene)
        if scene.camtrack_dome:
            _dome_toggled(scene, context)
        if captured:
            self.report({"INFO"}, f"Lit by your captured HDRI ({env_info.get('views', 0)} views)")
            return {"FINISHED"}
        pct = int(round(100 * float(room.get("coverage", 0))))
        self.report({"INFO"}, f"Lit by the rough HDRI. The phone saw {pct}% around it, the rest is estimated")
        return {"FINISHED"}


def _quat_mat(q):
    """[qx, qy, qz, qw] to a 3x3 numpy rotation."""
    import numpy as np
    x, y, z, w = q
    return np.array([
        [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
        [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
        [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
    ])


def _room_points(folder, data, stride=2, voxel=0.015):
    """Depth maps lifted into ARCore's world, coloured from the snapshots, thinned on a voxel grid."""
    import numpy as np
    depth_rows = data.get("depth") or []
    keys = (data.get("room") or {}).get("keyframes") or []
    snaps = []
    for i, k in enumerate(keys):
        path = os.path.join(folder, "room", "c_%03d.jpg" % i)
        if not os.path.exists(path):
            continue
        img = bpy.data.images.load(path, check_existing=False)
        w, h = img.size
        px = np.empty(w * h * 4, np.float32)
        img.pixels.foreach_get(px)
        bpy.data.images.remove(img)
        # Blender keeps rows bottom up; flip so row 0 is the top like the camera.
        px = px.reshape(h, w, 4)[::-1, :, :3]
        snaps.append((k[0], w, h, np.array(k[3:6]), _quat_mat(k[6:10]), k[10:14], px))

    pts, cols = [], []
    for n, row in enumerate(depth_rows):
        path = os.path.join(folder, "room", "d_%03d.bin" % n)
        if not os.path.exists(path):
            continue
        frame, w, h = int(row[0]), int(row[1]), int(row[2])
        t = np.array(row[3:6])
        R = _quat_mat(row[6:10])
        fx, fy, cx, cy = row[10:14]
        d = np.fromfile(path, dtype="<u2").reshape(h, w)[::stride, ::stride].astype(np.float32) / 1000.0
        vv, uu = np.mgrid[0:h:stride, 0:w:stride].astype(np.float32)
        ok = (d > 0.15) & (d < 6.0)
        z = d[ok]
        cam = np.stack([(uu[ok] + 0.5 - cx) / fx * z, -(vv[ok] + 0.5 - cy) / fy * z, -z], -1)
        world = cam @ R.T + t
        col = np.full((len(world), 3), 0.6, np.float32)
        if snaps:
            s = min(snaps, key=lambda s: abs(s[0] - frame))
            _, sw, sh, st, sR, (sfx, sfy, scx, scy), spx = s
            c = (world - st) @ sR
            front = -c[:, 2] > 0.05
            zz = np.where(front, -c[:, 2], 1.0)
            su = scx + sfx * c[:, 0] / zz
            sv = scy - sfy * c[:, 1] / zz
            inside = front & (su >= 0) & (sv >= 0) & (su < sw) & (sv < sh)
            col[inside] = spx[sv[inside].astype(int), su[inside].astype(int)]
        pts.append(world)
        cols.append(col)
    if not pts:
        return None, None
    P = np.concatenate(pts)
    C = np.concatenate(cols)
    # One point per voxel, averaged, so overlapping frames don't pile up.
    key = np.floor(P / voxel).astype(np.int64)
    _, inv, counts = np.unique(key, axis=0, return_inverse=True, return_counts=True)
    inv = inv.reshape(-1)
    out_p = np.zeros((len(counts), 3))
    out_c = np.zeros((len(counts), 3))
    np.add.at(out_p, inv, P)
    np.add.at(out_c, inv, C)
    out_p /= counts[:, None]
    out_c /= counts[:, None]
    # Lone voxels are mostly depth noise.
    keep = counts >= 2
    return out_p[keep], out_c[keep]


def _set_menu(node, name, value, prop, prop_value):
    """5.x exposes node options as menu sockets, 4.x as properties."""
    if name in node.inputs and node.inputs[name].type == "MENU":
        node.inputs[name].default_value = value
    elif hasattr(node, prop):
        setattr(node, prop, prop_value)


def _room_nodes(voxel):
    ng = bpy.data.node_groups.new("Camera Tracker room mesh", "GeometryNodeTree")
    ng.interface.new_socket("Geometry", in_out="INPUT", socket_type="NodeSocketGeometry")
    ng.interface.new_socket("Geometry", in_out="OUTPUT", socket_type="NodeSocketGeometry")
    sock = ng.interface.new_socket("Thickness", in_out="INPUT", socket_type="NodeSocketFloat")
    sock.default_value = voxel * 1.5
    sock.min_value = 0.005
    N = ng.nodes
    L = ng.links
    gin = N.new("NodeGroupInput")
    gout = N.new("NodeGroupOutput")
    m2p = N.new("GeometryNodeMeshToPoints")
    p2v = N.new("GeometryNodePointsToVolume")
    _set_menu(p2v, "Resolution Mode", "Size", "resolution_mode", "VOXEL_SIZE")
    p2v.inputs["Voxel Size"].default_value = voxel
    v2m = N.new("GeometryNodeVolumeToMesh")
    _set_menu(v2m, "Resolution Mode", "Grid", "resolution_mode", "GRID")
    v2m.inputs["Threshold"].default_value = 0.3
    pos = N.new("GeometryNodeInputPosition")
    near = N.new("GeometryNodeSampleNearest")
    attr = N.new("GeometryNodeInputNamedAttribute")
    attr.data_type = "FLOAT_COLOR"
    attr.inputs["Name"].default_value = "Col"
    samp = N.new("GeometryNodeSampleIndex")
    samp.data_type = "FLOAT_COLOR"
    store = N.new("GeometryNodeStoreNamedAttribute")
    store.data_type = "FLOAT_COLOR"
    store.inputs["Name"].default_value = "Col"
    setmat = N.new("GeometryNodeSetMaterial")

    L.new(gin.outputs[0], m2p.inputs["Mesh"])
    L.new(m2p.outputs["Points"], p2v.inputs["Points"])
    L.new(gin.outputs[1], p2v.inputs["Radius"])
    L.new(p2v.outputs[0], v2m.inputs["Volume"])
    L.new(gin.outputs[0], near.inputs["Geometry"])
    L.new(pos.outputs["Position"], near.inputs["Sample Position"])
    L.new(gin.outputs[0], samp.inputs["Geometry"])
    L.new(attr.outputs[0], samp.inputs["Value"])
    L.new(near.outputs["Index"], samp.inputs["Index"])
    # The volume wraps every point in a ball, so its surface floats one radius above
    # the real one. Pull it back in along the normals onto the measured depth.
    shrink = N.new("GeometryNodeSetPosition")
    normal = N.new("GeometryNodeInputNormal")
    scale = N.new("ShaderNodeVectorMath")
    scale.operation = "SCALE"
    neg = N.new("ShaderNodeMath")
    neg.operation = "MULTIPLY"
    neg.inputs[1].default_value = -0.9
    L.new(gin.outputs[1], neg.inputs[0])
    L.new(normal.outputs["Normal"], scale.inputs[0])
    L.new(neg.outputs[0], scale.inputs["Scale"])
    L.new(v2m.outputs["Mesh"], shrink.inputs["Geometry"])
    L.new(scale.outputs["Vector"], shrink.inputs["Offset"])
    shrink.location = (700, 200)
    normal.location = (300, 380)
    scale.location = (480, 380)
    neg.location = (300, 520)
    # Smooth the voxel steps away: blockiness reads as false shadow in EEVEE and
    # as stair stepping in reflections.
    blur = N.new("GeometryNodeBlurAttribute")
    blur.data_type = "FLOAT_VECTOR"
    blur.inputs["Iterations"].default_value = 4
    blur.inputs["Weight"].default_value = 1.0
    blur_pos = N.new("GeometryNodeInputPosition")
    smooth = N.new("GeometryNodeSetPosition")
    shade = N.new("GeometryNodeSetShadeSmooth")
    L.new(blur_pos.outputs["Position"], blur.inputs[0])
    L.new(shrink.outputs["Geometry"], smooth.inputs["Geometry"])
    L.new(blur.outputs[0], smooth.inputs["Position"])
    L.new(smooth.outputs["Geometry"], shade.inputs["Geometry"])
    blur_pos.location = (700, 420)
    blur.location = (880, 420)
    smooth.location = (900, 200)
    shade.location = (1080, 200)
    L.new(shade.outputs["Geometry"], store.inputs["Geometry"])
    L.new(samp.outputs[0], store.inputs["Value"])
    L.new(store.outputs[0], setmat.inputs["Geometry"])
    L.new(setmat.outputs[0], gout.inputs[0])
    for i, n in enumerate([gin, m2p, p2v, v2m, store, setmat, gout]):
        n.location = (i * 220, 0)
    for i, n in enumerate([pos, attr, near, samp]):
        n.location = (440 + i * 200, -260)
    return ng, setmat


class CAMTRACK_OT_room_mesh(bpy.types.Operator):
    """Build a rough coloured mesh of the room from the phone's depth, for shadows, occlusion and reflections"""
    bl_idname = "camtrack.room_mesh"
    bl_label = "Build room mesh"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        root = _active_root(context)
        if root is None:
            self.report({"ERROR"}, "Select something from an imported take first")
            return {"CANCELLED"}
        track = bpy.path.abspath(root[ROOT_KEY])
        data = _load(track)
        if not data.get("depth"):
            self.report({"WARNING"}, "This shot has no depth. The phone may not support ARCore depth")
            return {"CANCELLED"}
        for old in [c for c in root.children if c.name.endswith(" room")]:
            bpy.data.objects.remove(old)
        voxel = 0.02
        P, C = _room_points(os.path.dirname(track), data, voxel=voxel)
        if P is None or len(P) == 0:
            self.report({"ERROR"}, "No usable depth in this shot")
            return {"CANCELLED"}

        name = root.name.replace(" origin", "") + " room"
        mesh = bpy.data.meshes.new(name)
        mesh.vertices.add(len(P))
        mesh.vertices.foreach_set("co", P.astype("float32").ravel())
        col = mesh.color_attributes.new("Col", "FLOAT_COLOR", "POINT")
        import numpy as np
        rgba = np.concatenate([C, np.ones((len(C), 1))], 1).astype("float32")
        col.data.foreach_set("color", rgba.ravel())
        mesh.update()
        obj = bpy.data.objects.new(name, mesh)
        root.users_collection[0].objects.link(obj)
        obj.parent = root

        mat = bpy.data.materials.new(name)
        mat.use_nodes = True
        nt = mat.node_tree
        bsdf = nt.nodes["Principled BSDF"]
        a = nt.nodes.new("ShaderNodeAttribute")
        a.attribute_name = "Col"
        a.location = (-300, 200)
        nt.links.new(a.outputs["Color"], bsdf.inputs["Base Color"])
        bsdf.inputs["Roughness"].default_value = 0.85

        ng, setmat = _room_nodes(voxel)
        setmat.inputs["Material"].default_value = mat
        mod = obj.modifiers.new("Room mesh", "NODES")
        mod.node_group = ng
        # Seen only through what it does to your objects: shadows land on it and it hides what is behind it.
        _make_catcher(obj, _catcher_material(_estimate_lit(context.scene), context.scene))
        if context.scene.render.engine not in {"CYCLES", _eevee_id()}:
            context.scene.render.engine = "CYCLES"
        context.scene.render.film_transparent = True
        self.report({"INFO"}, f"Room mesh from {len(data['depth'])} depth frames. It catches shadows and hides objects behind real things")
        return {"FINISHED"}


class CAMTRACK_OT_setup(bpy.types.Operator):
    """Set up everything for this shot: resolution, frame rate, camera, render settings, shadows, lighting and the composite"""
    bl_idname = "camtrack.setup"
    bl_label = "Set up scene"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        root = _active_root(context)
        cam = _take_camera(root) if root else None
        if cam is None:
            self.report({"ERROR"}, "Import a take first")
            return {"CANCELLED"}
        track = bpy.path.abspath(root[ROOT_KEY])
        data = _load(track)
        folder = os.path.dirname(track)
        scene = context.scene
        name = root.name.replace(" origin", "")

        # The shot's own size, rate and length.
        scene.render.resolution_x = data["width"]
        scene.render.resolution_y = data["height"]
        scene.render.resolution_percentage = 100
        scene.render.pixel_aspect_x = scene.render.pixel_aspect_y = 1
        scene.render.fps = int(data["fps"])
        scene.render.fps_base = 1.0
        offset = int(cam.get("camtrack_offset", 0))
        scene.frame_start = 1 + offset
        scene.frame_end = len(data["frames"]) + offset
        scene.frame_set(scene.frame_start)
        scene.camera = cam

        # Render: Cycles with a clean plate. Standard view keeps the video's colours as filmed.
        if scene.render.engine != _eevee_id():
            scene.render.engine = "CYCLES"
        scene.cycles.samples = 128
        scene.cycles.use_denoising = True
        scene.render.film_transparent = True
        try:
            scene.view_settings.view_transform = "Standard"
            scene.view_settings.look = "None"
        except TypeError:
            pass

        # Motion blur so CG moves smear like the filmed picture does. A 180 degree
        # shutter (half a frame) is what phones roughly give in normal light.
        scene.render.use_motion_blur = True
        scene.render.motion_blur_shutter = 0.5

        done = []
        # Shadows: the room mesh when the phone had depth, else a floor catcher.
        has_mesh = any(c.name.endswith(" room") for c in root.children)
        if data.get("depth") and not has_mesh:
            if "FINISHED" in bpy.ops.camtrack.room_mesh():
                has_mesh = True
                done.append("room mesh")
        if not has_mesh:
            bpy.ops.camtrack.shadow_catcher()
            done.append("shadow catcher")
        else:
            for old in [c for c in root.children if c.name.startswith("Shadow catcher")]:
                bpy.data.objects.remove(old)

        # Light: the room HDR when there is one, else a sun from the measured light.
        hdr = os.path.join(folder, (data.get("room") or {}).get("hdr", "env.hdr"))
        if os.path.exists(hdr) and "FINISHED" in bpy.ops.camtrack.room_light():
            done.append("HDRI lighting")
        elif data.get("light") and "FINISHED" in bpy.ops.camtrack.match_light():
            done.append("sun from the real light")

        bpy.ops.camtrack.composite()
        done.append("composite")
        if _find_catcher(scene):
            _catcher_material(_estimate_lit(scene), scene)
            if scene.render.engine == _eevee_id():
                _calibrate_eevee(scene)

        # Output: an image sequence next to the .blend, or next to the shot if unsaved.
        base = "//render/" if bpy.data.filepath else os.path.join(folder, "render") + os.sep
        scene.render.filepath = base + name + "_"
        scene.render.image_settings.file_format = "PNG"

        # Look through the phone with the sidebar open, like after import.
        for window in context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == "VIEW_3D":
                    space = area.spaces.active
                    space.region_3d.view_perspective = "CAMERA"
                    space.show_region_ui = True
        self.report({"INFO"}, "Ready: " + ", ".join(done) + ". Add your objects, then F12 or Render Animation")
        return {"FINISHED"}


CATCHER_MAT = "Shadow catcher (Cycles + EEVEE)"


def _eevee_id():
    items = [e.identifier for e in bpy.types.RenderSettings.bl_rna.properties["engine"].enum_items]
    return "BLENDER_EEVEE_NEXT" if "BLENDER_EEVEE_NEXT" in items else "BLENDER_EEVEE"


def _estimate_lit(scene):
    """Roughly how bright a white floor would be with nothing shadowing it, so the
    EEVEE catcher knows what "no shadow" looks like."""
    lit = 0.0
    up = Vector((0, 0, 1))
    for o in scene.objects:
        if o.type == "LIGHT" and o.data.type == "SUN" and not o.hide_render:
            towards = (o.matrix_world.to_3x3() @ Vector((0, 0, 1))).normalized()
            # A white diffuse floor under a sun of strength E shows E * cos / pi.
            lit += o.data.energy * max(0.0, towards.dot(up)) / math.pi
    world = scene.world
    if world and world.node_tree:
        bg = next((n for n in world.node_tree.nodes if n.type == "BACKGROUND"), None)
        env = next((n for n in world.node_tree.nodes if n.type == "TEX_ENVIRONMENT"), None)
        strength = bg.inputs["Strength"].default_value if bg else 1.0
        if env and env.image:
            img = env.image
            w, h = img.size
            if w and h:
                import numpy as np
                px = np.empty(w * h * 4, np.float32)
                img.pixels.foreach_get(px)
                px = px.reshape(h, w, 4)[..., :3].mean(-1)
                # Light reaching a floor: the upper half, weighted by how high it is.
                rows = np.arange(h)
                el = (rows + 0.5) / h * math.pi - math.pi / 2  # bottom row first in Blender
                wgt = np.clip(np.sin(el), 0, None) * np.cos(el)
                lit += float((px.mean(1) * wgt).sum() / max(wgt.sum(), 1e-6)) * 2.0 * strength
        elif bg:
            c = bg.inputs["Color"].default_value
            lit += (c[0] + c[1] + c[2]) / 3.0 * strength
    return max(0.05, lit)


def _find_catcher(scene):
    """The catcher material this scene's take uses, if any. Cheap: the panel calls it on every redraw."""
    root = _root_of(scene.camera) if scene else None
    if root is not None:
        mat = bpy.data.materials.get(f"{CATCHER_MAT} ({root.name.replace(' origin', '')})")
        if mat:
            return mat
    return bpy.data.materials.get(CATCHER_MAT)


def _catcher_material(lit, scene=None):
    """One material, two outputs, after Ian Hubert's footage-on-geometry trick.

    Cycles: the camera sees a plain white surface, so Cycles' own shadow catcher
    does the shadows; every other ray (reflections, bounce light) sees the video
    projected from the moving camera, glowing, so the real floor and walls light
    and reflect in your objects.

    EEVEE: the surface is that glowing video, darkened where your objects shadow
    it, so it also hides what is behind it and shows up in reflections. Without a
    video it falls back to a shadow only holdout."""
    take = _take_video(scene) if scene is not None else None
    name = CATCHER_MAT + (f" ({take[6]})" if take else "")
    mat = bpy.data.materials.get(name)
    if mat is not None and mat.get("camtrack_v", 1) < 3:
        mat.node_tree.nodes.clear()
    if mat is None or not mat.node_tree.nodes:
        mat = mat or bpy.data.materials.new(name)
        mat["camtrack_v"] = 3
        mat.use_nodes = True
        nt = mat.node_tree
        nt.nodes.clear()
        N, L = nt.nodes, nt.links
        out_c = N.new("ShaderNodeOutputMaterial"); out_c.target = "CYCLES"; out_c.location = (900, 250)
        out_e = N.new("ShaderNodeOutputMaterial"); out_e.target = "EEVEE"; out_e.location = (900, -50)
        white = N.new("ShaderNodeBsdfDiffuse"); white.location = (600, 300)
        L.new(white.outputs[0], out_c.inputs["Surface"])

        probe = N.new("ShaderNodeBsdfDiffuse"); probe.location = (-600, 0)
        to_rgb = N.new("ShaderNodeShaderToRGB"); to_rgb.location = (-400, 0)
        bw = N.new("ShaderNodeRGBToBW"); bw.location = (-220, 0)
        # "No shadow" brightness for this surface: the room's ambient light plus the
        # key sun for the way the surface faces (white diffuse shows E * cos / pi).
        lit_v = N.new("ShaderNodeValue"); lit_v.name = lit_v.label = "Lit level"; lit_v.location = (-800, -300)
        sun_v = N.new("ShaderNodeValue"); sun_v.name = sun_v.label = "Sun level"; sun_v.outputs[0].default_value = 0.0; sun_v.location = (-800, -420)
        sun_d = N.new("ShaderNodeCombineXYZ"); sun_d.name = sun_d.label = "Sun direction"; sun_d.inputs[2].default_value = 1.0; sun_d.location = (-800, -540)
        geo = N.new("ShaderNodeNewGeometry"); geo.location = (-800, -700)
        dot = N.new("ShaderNodeVectorMath"); dot.operation = "DOT_PRODUCT"; dot.location = (-600, -560)
        facing = N.new("ShaderNodeMath"); facing.operation = "MAXIMUM"; facing.inputs[1].default_value = 0.0; facing.location = (-440, -520)
        ref = N.new("ShaderNodeMath"); ref.operation = "MULTIPLY_ADD"; ref.location = (-260, -360)
        L.new(geo.outputs["Normal"], dot.inputs[0])
        L.new(sun_d.outputs[0], dot.inputs[1])
        L.new(dot.outputs["Value"], facing.inputs[0])
        L.new(facing.outputs[0], ref.inputs[0])
        L.new(sun_v.outputs[0], ref.inputs[1])
        L.new(lit_v.outputs[0], ref.inputs[2])
        div = N.new("ShaderNodeMath"); div.operation = "DIVIDE"; div.use_clamp = True; div.location = (-40, 0)
        inv = N.new("ShaderNodeMath"); inv.operation = "SUBTRACT"; inv.inputs[0].default_value = 1.0; inv.use_clamp = True; inv.location = (140, 0)
        str_v = N.new("ShaderNodeValue"); str_v.name = str_v.label = "Shadow strength"; str_v.outputs[0].default_value = 1.0; str_v.location = (140, -150)
        mul = N.new("ShaderNodeMath"); mul.operation = "MULTIPLY"; mul.use_clamp = True; mul.location = (320, 0)
        hold = N.new("ShaderNodeHoldout"); hold.location = (500, 100)
        black = N.new("ShaderNodeEmission"); black.inputs["Color"].default_value = (0, 0, 0, 1); black.location = (500, -120)
        mix = N.new("ShaderNodeMixShader"); mix.location = (700, -50)
        L.new(probe.outputs[0], to_rgb.inputs[0])
        L.new(to_rgb.outputs["Color"], bw.inputs[0])
        L.new(bw.outputs[0], div.inputs[0])
        # 25% dead zone: the estimate runs a little high, and lit floor must stay exactly as filmed.
        scale = N.new("ShaderNodeMath"); scale.operation = "MULTIPLY"; scale.inputs[1].default_value = 0.75; scale.location = (-40, -150)
        L.new(ref.outputs[0], scale.inputs[0])
        L.new(scale.outputs[0], div.inputs[1])
        L.new(div.outputs[0], inv.inputs[1])
        L.new(inv.outputs[0], mul.inputs[0])
        L.new(str_v.outputs[0], mul.inputs[1])
        L.new(mul.outputs[0], mix.inputs["Fac"])
        L.new(hold.outputs[0], mix.inputs[1])
        L.new(black.outputs[0], mix.inputs[2])
        L.new(mix.outputs[0], out_e.inputs["Surface"])
        mat.diffuse_color = (0.85, 0.85, 0.85, 0.35)

        if take:
            cam, img, w, h, total, ambient, _ = take
            tex = _projection_nodes(nt, cam, img, 1, total, True, w, h, cam, x0=-1900, y0=700)
            # Outside the frame the video has nothing; use the room's filmed colour there.
            room_c = N.new("ShaderNodeRGB"); room_c.name = room_c.label = "Room colour"; room_c.location = (-760, 900)
            room_c.outputs[0].default_value = (*ambient, 1.0)
            fill = N.new("ShaderNodeMix"); fill.data_type = "RGBA"; fill.location = (-560, 800)
            L.new(tex.outputs["Alpha"], fill.inputs[0])
            L.new(room_c.outputs[0], fill.inputs[6])
            L.new(tex.outputs["Color"], fill.inputs[7])
            # Cycles: camera rays get the catcher, everything else the glowing video.
            glow = N.new("ShaderNodeEmission"); glow.location = (400, 520)
            L.new(fill.outputs[2], glow.inputs["Color"])
            path = N.new("ShaderNodeLightPath"); path.location = (400, 750)
            pick = N.new("ShaderNodeMixShader"); pick.location = (700, 400)
            L.new(path.outputs["Is Camera Ray"], pick.inputs["Fac"])
            L.new(glow.outputs[0], pick.inputs[1])
            L.new(white.outputs[0], pick.inputs[2])
            L.new(pick.outputs[0], out_c.inputs["Surface"])
            # EEVEE: the video, darkened by the shadow amount.
            keep = N.new("ShaderNodeMath"); keep.operation = "SUBTRACT"; keep.inputs[0].default_value = 1.0; keep.use_clamp = True; keep.location = (500, -260)
            L.new(mul.outputs[0], keep.inputs[1])
            shade = N.new("ShaderNodeVectorMath"); shade.operation = "SCALE"; shade.location = (680, -260)
            L.new(fill.outputs[2], shade.inputs[0])
            L.new(keep.outputs[0], shade.inputs["Scale"])
            ev = N.new("ShaderNodeEmission"); ev.location = (860, -260)
            L.new(shade.outputs["Vector"], ev.inputs["Color"])
            L.new(ev.outputs[0], out_e.inputs["Surface"])
            mat["camtrack_video"] = True
    if mat.get("camtrack_calibrated") is None:
        mat.node_tree.nodes["Lit level"].outputs[0].default_value = lit
    return mat


def _make_catcher(obj, mat):
    obj.is_shadow_catcher = True
    if obj.type != "MESH":
        return
    for m in obj.modifiers:
        if m.type == "NODES" and m.node_group:
            for n in m.node_group.nodes:
                if n.bl_idname == "GeometryNodeSetMaterial":
                    n.inputs["Material"].default_value = mat
    obj.data.materials.clear()
    obj.data.materials.append(mat)


def _calibrate_eevee(scene):
    """Measures how bright the catchers really are with nothing of yours in the
    way: one tiny EEVEE render of their light alone, with every non catcher mesh
    hidden. That number is "no shadow"; anything darker in the real render is a
    shadow your objects cast. Returns the level, or None."""
    import tempfile
    import numpy as np
    mat = _find_catcher(scene)
    if mat is None:
        return None
    nt = mat.node_tree
    out_e = next((n for n in nt.nodes if n.type == "OUTPUT_MATERIAL" and n.target == "EEVEE"), None)
    bw = next((n for n in nt.nodes if n.type == "RGBTOBW"), None)
    if out_e is None or bw is None:
        return None
    old_link = out_e.inputs["Surface"].links[0].from_socket if out_e.inputs["Surface"].links else None
    probe = nt.nodes.new("ShaderNodeEmission")
    nt.links.new(bw.outputs[0], probe.inputs["Color"])
    nt.links.new(probe.outputs[0], out_e.inputs["Surface"])

    hidden = []
    suns = [o for o in scene.objects if o.type == "LIGHT" and o.data.type == "SUN" and not o.hide_render]
    for o in scene.objects:
        if o.type == "MESH" and not o.hide_render and not any(m == mat for m in o.data.materials):
            o.hide_render = True
            hidden.append(o)
    # Ambient alone: the sun's share is added per surface from its angle.
    for o in suns:
        o.hide_render = True
        hidden.append(o)
    r = scene.render
    saved = (r.engine, r.resolution_percentage, r.use_compositing, r.film_transparent, r.use_motion_blur,
             r.filepath, r.image_settings.file_format, r.image_settings.color_depth,
             getattr(scene.eevee, "taa_render_samples", 16))
    path = os.path.join(tempfile.gettempdir(), "camtrack_calibrate.exr")
    level = None
    try:
        r.engine = _eevee_id()
        r.resolution_percentage = 15
        r.use_compositing = False
        r.film_transparent = True
        r.use_motion_blur = False
        r.image_settings.file_format = "OPEN_EXR"
        r.image_settings.color_depth = "32"
        r.filepath = path
        scene.eevee.taa_render_samples = 8
        bpy.ops.render.render(write_still=True, scene=scene.name)
        img = bpy.data.images.load(path, check_existing=False)
        px = np.empty(img.size[0] * img.size[1] * 4, np.float32)
        img.pixels.foreach_get(px)
        bpy.data.images.remove(img)
        px = px.reshape(-1, 4)
        catcher = px[px[:, 3] > 0.5, 0]
        if len(catcher) > 50:
            # The lit floor is most of it; the 75th percentile skips real dark spots.
            level = float(np.percentile(catcher, 60))
    finally:
        (r.engine, r.resolution_percentage, r.use_compositing, r.film_transparent, r.use_motion_blur,
         r.filepath, r.image_settings.file_format, r.image_settings.color_depth, samples) = saved
        scene.eevee.taa_render_samples = samples
        for o in hidden:
            o.hide_render = False
        nt.nodes.remove(probe)
        if old_link is not None:
            nt.links.new(old_link, out_e.inputs["Surface"])
    if level and level > 1e-4:
        nt.nodes["Lit level"].outputs[0].default_value = level
        mat["camtrack_calibrated"] = True
    key = max(suns, key=lambda o: o.data.energy, default=None)
    if key is not None and "Sun level" in nt.nodes:
        c = key.data.color
        lum = 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]
        nt.nodes["Sun level"].outputs[0].default_value = key.data.energy * lum / math.pi
        towards = (key.matrix_world.to_3x3() @ Vector((0, 0, 1))).normalized()
        for i in range(3):
            nt.nodes["Sun direction"].inputs[i].default_value = towards[i]
    elif "Sun level" in nt.nodes:
        nt.nodes["Sun level"].outputs[0].default_value = 0.0
    return level


class CAMTRACK_OT_calibrate(bpy.types.Operator):
    """Measure the real floor brightness so EEVEE only darkens where your objects cast shadows. Run it again after changing the lights"""
    bl_idname = "camtrack.calibrate"
    bl_label = "Recalibrate EEVEE shadows"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        level = _calibrate_eevee(context.scene)
        if level is None:
            self.report({"WARNING"}, "No shadow catcher to calibrate")
            return {"CANCELLED"}
        self.report({"INFO"}, f"EEVEE shadows calibrated (floor level {level:.3f})")
        return {"FINISHED"}


class CAMTRACK_OT_make_catcher(bpy.types.Operator):
    """Turn the selected objects into shadow catchers that work in both Cycles and EEVEE"""
    bl_idname = "camtrack.make_catcher"
    bl_label = "Make selected a shadow catcher"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        objs = [o for o in context.selected_objects if o.type == "MESH"]
        if not objs:
            self.report({"WARNING"}, "Select one or more meshes first")
            return {"CANCELLED"}
        mat = _catcher_material(_estimate_lit(context.scene), context.scene)
        for o in objs:
            _make_catcher(o, mat)
        context.scene.render.film_transparent = True
        if context.scene.render.engine == _eevee_id():
            _calibrate_eevee(context.scene)
        self.report({"INFO"}, f"{len(objs)} shadow catcher{'s' if len(objs) > 1 else ''}, for Cycles and EEVEE")
        return {"FINISHED"}


class CAMTRACK_OT_engine(bpy.types.Operator):
    """Switch the render engine, keeping the shadow catchers working"""
    bl_idname = "camtrack.engine"
    bl_label = "Render engine"
    bl_options = {"REGISTER", "UNDO"}

    engine: StringProperty()

    def execute(self, context):
        scene = context.scene
        if self.engine == "EEVEE":  # noqa
            scene.render.engine = _eevee_id()
            ee = scene.eevee
            # Ray traced indirect light gives the soft darkening around objects that
            # Cycles' catcher has, and softer, longer sun shadows.
            for prop, value in (("use_raytracing", True), ("use_fast_gi", True), ("use_shadows", True),
                                ("shadow_ray_count", 2), ("shadow_step_count", 8), ("taa_render_samples", 64)):
                if hasattr(ee, prop):
                    setattr(ee, prop, value)
            if scene.world and hasattr(scene.world, "sun_threshold"):
                # Lets EEVEE pull a shadow casting sun out of the room HDR.
                scene.world.sun_threshold = 2.0
        else:
            scene.render.engine = "CYCLES"
        scene.render.film_transparent = True
        mat = _find_catcher(scene)
        if mat:
            _catcher_material(_estimate_lit(scene), scene)
            if self.engine == "EEVEE":
                _calibrate_eevee(scene)
        return {"FINISHED"}


def _projection_nodes(nt, projector, image, frame, total, follow, w, h, lens_obj, x0=-1100, y0=0):
    """Camera projection in the shader (Ian Hubert's footage-on-geometry trick):
    every point looks itself up in the video through the projector camera's lens.
    No UVs needed, so it works on generated meshes too. Returns the image node."""
    N, L = nt.nodes, nt.links
    cam = lens_obj.data
    big = float(max(w, h))
    k = cam.lens / cam.sensor_width  # focal length over the long side of the frame
    ku, kv = k * big / w, k * big / h
    su, sv = cam.shift_x * big / w, cam.shift_y * big / h
    tc = N.new("ShaderNodeTexCoord"); tc.object = projector; tc.location = (x0, y0)
    sep = N.new("ShaderNodeSeparateXYZ"); sep.location = (x0 + 200, y0)
    negz = N.new("ShaderNodeMath"); negz.operation = "MULTIPLY"; negz.inputs[1].default_value = -1.0; negz.location = (x0 + 400, y0 - 200)
    dx = N.new("ShaderNodeMath"); dx.operation = "DIVIDE"; dx.location = (x0 + 580, y0 + 100)
    dy = N.new("ShaderNodeMath"); dy.operation = "DIVIDE"; dy.location = (x0 + 580, y0 - 60)
    u = N.new("ShaderNodeMath"); u.operation = "MULTIPLY_ADD"; u.inputs[1].default_value = ku; u.inputs[2].default_value = 0.5 - su; u.location = (x0 + 760, y0 + 100)
    v = N.new("ShaderNodeMath"); v.operation = "MULTIPLY_ADD"; v.inputs[1].default_value = kv; v.inputs[2].default_value = 0.5 - sv; v.location = (x0 + 760, y0 - 60)
    comb = N.new("ShaderNodeCombineXYZ"); comb.location = (x0 + 940, y0)
    tex = N.new("ShaderNodeTexImage"); tex.name = "Video"; tex.image = image; tex.extension = "CLIP"; tex.location = (x0 + 1120, y0)
    iu = tex.image_user
    iu.frame_start = 1
    iu.use_cyclic = False
    iu.use_auto_refresh = True
    if follow:
        iu.frame_duration = total
        iu.frame_offset = 0
    else:
        iu.frame_duration = 1
        iu.frame_offset = frame - 1
    L.new(tc.outputs["Object"], sep.inputs[0])
    L.new(sep.outputs["Z"], negz.inputs[0])
    L.new(sep.outputs["X"], dx.inputs[0]); L.new(negz.outputs[0], dx.inputs[1])
    L.new(sep.outputs["Y"], dy.inputs[0]); L.new(negz.outputs[0], dy.inputs[1])
    L.new(dx.outputs[0], u.inputs[0]); L.new(dy.outputs[0], v.inputs[0])
    L.new(u.outputs[0], comb.inputs["X"]); L.new(v.outputs[0], comb.inputs["Y"])
    L.new(comb.outputs[0], tex.inputs["Vector"])
    return tex


def _projection_material(name, projector, image, frame, total, follow, w, h, lens_obj):
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    tex = _projection_nodes(nt, projector, image, frame, total, follow, w, h, lens_obj)
    emit = nt.nodes.new("ShaderNodeEmission"); emit.location = (320, 0)
    out = nt.nodes.new("ShaderNodeOutputMaterial"); out.location = (520, 0)
    # Emission keeps the filmed pixels exactly as filmed, and lets them light the scene.
    nt.links.new(tex.outputs["Color"], emit.inputs["Color"])
    nt.links.new(emit.outputs[0], out.inputs["Surface"])
    return mat


def _take_video(scene):
    """The scene's take: (camera, movie image, width, height, frames, ambient colour), or None."""
    root = _root_of(scene.camera)
    cam = _take_camera(root) if root else None
    if cam is None:
        return None
    try:
        track = bpy.path.abspath(root[ROOT_KEY])
        data = _load(track)
    except Exception:
        return None
    video = os.path.join(os.path.dirname(track), data.get("video", "shot.mp4"))
    if not os.path.exists(video):
        return None
    img = bpy.data.images.load(video, check_existing=True)
    img.source = "MOVIE"
    ambient = _filmed_ambient(os.path.dirname(track), data.get("room") or {})
    name = root.name.replace(" origin", "")
    return cam, img, data["width"], data["height"], len(data["frames"]), ambient, name


class CAMTRACK_OT_project(bpy.types.Operator):
    """Paint the video onto the selected objects from the phone's view (camera projection), so they can be moved, broken or extruded with the real texture"""
    bl_idname = "camtrack.project"
    bl_label = "Project the video onto selected"
    bl_options = {"REGISTER", "UNDO"}

    follow: BoolProperty(name="Follow the video", default=False,
                         description="Re-project every frame from the moving camera (good for reflections). Off freezes the current frame onto the objects")

    def execute(self, context):
        root = _active_root(context)
        if root is None:
            root = _root_of(context.scene.camera)
        cam = _take_camera(root) if root else None
        objs = [o for o in context.selected_objects if o.type == "MESH"]
        if cam is None or not objs:
            self.report({"ERROR"}, "Select the meshes to paint, with a take imported")
            return {"CANCELLED"}
        track = bpy.path.abspath(root[ROOT_KEY])
        data = _load(track)
        video = os.path.join(os.path.dirname(track), data.get("video", "shot.mp4"))
        img = bpy.data.images.load(video, check_existing=True)
        img.source = "MOVIE"
        scene = context.scene
        frame = scene.frame_current
        w, h = data["width"], data["height"]
        if self.follow:
            projector = cam
            name = "Projected video (follows)"
        else:
            # A still copy of the phone camera, frozen where it was on this frame.
            pdata = cam.data.copy()
            pdata.animation_data_clear()
            pdata.show_background_images = False
            projector = bpy.data.objects.new(f"Projector f{frame}", pdata)
            root.users_collection[0].objects.link(projector)
            projector.matrix_world = cam.matrix_world.copy()
            projector.hide_render = True
            name = f"Projected frame {frame}"
        mat = _projection_material(name, projector, img, frame, len(data["frames"]), self.follow, w, h, projector)
        for o in objs:
            o.is_shadow_catcher = False
            for m in o.modifiers:
                if m.type == "NODES" and m.node_group:
                    for n in m.node_group.nodes:
                        if n.bl_idname == "GeometryNodeSetMaterial":
                            n.inputs["Material"].default_value = mat
            o.data.materials.clear()
            o.data.materials.append(mat)
        self.report({"INFO"}, f"Projected frame {frame} onto {len(objs)} object{'s' if len(objs) > 1 else ''}" if not self.follow
                    else f"The moving video now projects onto {len(objs)} object{'s' if len(objs) > 1 else ''}")
        return {"FINISHED"}


# ---------------------------------------------------------------------- panel

# ------------------------------------------------------------------ HDRI dome

DOME_MAT = "HDRI dome"


def _world_from_hdr(scene, hdr, rot_z):
    """Lights the scene with an HDRI at infinity: the dome is only what you see."""
    world = bpy.data.worlds.new("HDRI " + os.path.splitext(os.path.basename(hdr))[0])
    scene.world = world
    if hasattr(world, "use_nodes"):
        world.use_nodes = True
    nt = world.node_tree
    bg = next(n for n in nt.nodes if n.type == "BACKGROUND")
    env = nt.nodes.new("ShaderNodeTexEnvironment")
    env.image = bpy.data.images.load(hdr, check_existing=True)
    coord = nt.nodes.new("ShaderNodeTexCoord")
    mapping = nt.nodes.new("ShaderNodeMapping")
    mapping.inputs["Rotation"].default_value[2] = rot_z
    nt.links.new(coord.outputs["Generated"], mapping.inputs["Vector"])
    nt.links.new(mapping.outputs["Vector"], env.inputs["Vector"])
    nt.links.new(env.outputs["Color"], bg.inputs["Color"])
    if hasattr(world, "sun_threshold"):
        world.sun_threshold = 2.0


def _dome_material(name, image, eye, rot_z, lit, floor, lit_rgb=(1.0, 1.0, 1.0)):
    """The HDRI as seen from the point it was captured at, painted onto real geometry.

    Every surface point looks the HDRI up along the line from the capture point
    through itself, so the HDRI's ground lands on the floor at the right size and
    stays put as the camera moves. The floor darkens where your objects shadow it."""
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    N, L = nt.nodes, nt.links
    coord = N.new("ShaderNodeTexCoord"); coord.object = eye; coord.location = (-900, 0)
    mapping = N.new("ShaderNodeMapping"); mapping.name = mapping.label = "HDRI rotation"; mapping.location = (-700, 0)
    mapping.inputs["Rotation"].default_value[2] = rot_z
    env = N.new("ShaderNodeTexEnvironment"); env.image = image; env.location = (-500, 0)
    L.new(coord.outputs["Object"], mapping.inputs["Vector"])
    L.new(mapping.outputs["Vector"], env.inputs["Vector"])
    glow = N.new("ShaderNodeEmission"); glow.location = (300, 200)
    L.new(env.outputs["Color"], glow.inputs["Color"])
    out_c = N.new("ShaderNodeOutputMaterial"); out_c.target = "CYCLES"; out_c.location = (900, 200)
    lit_v = N.new("ShaderNodeValue"); lit_v.name = lit_v.label = "Lit level"; lit_v.location = (-300, -480)
    lit_v.outputs[0].default_value = lit
    if floor:
        # Cycles: a real diffuse floor whose colour is the HDRI divided by how lit it
        # is, so unshadowed it shows the HDRI exactly, and shadows and bounce come for free.
        # Per colour, or the sky's blue tints the ground twice.
        tint = N.new("ShaderNodeRGB"); tint.name = tint.label = "Sky tint"; tint.location = (-300, 600)
        tint.outputs[0].default_value = (*lit_rgb, 1.0)
        divisor = N.new("ShaderNodeVectorMath"); divisor.operation = "SCALE"; divisor.location = (-100, 600)
        L.new(tint.outputs[0], divisor.inputs[0])
        L.new(lit_v.outputs[0], divisor.inputs["Scale"])
        albedo = N.new("ShaderNodeVectorMath"); albedo.operation = "DIVIDE"; albedo.location = (100, 420)
        L.new(env.outputs["Color"], albedo.inputs[0])
        L.new(divisor.outputs["Vector"], albedo.inputs[1])
        ground = N.new("ShaderNodeBsdfDiffuse"); ground.location = (300, 420)
        L.new(albedo.outputs["Vector"], ground.inputs["Color"])
        path = N.new("ShaderNodeLightPath"); path.location = (300, 650)
        pick = N.new("ShaderNodeMixShader"); pick.location = (600, 300)
        L.new(path.outputs["Is Camera Ray"], pick.inputs["Fac"])
        L.new(glow.outputs[0], pick.inputs[1])
        L.new(ground.outputs[0], pick.inputs[2])
        L.new(pick.outputs[0], out_c.inputs["Surface"])
    else:
        L.new(glow.outputs[0], out_c.inputs["Surface"])
        out_e = N.new("ShaderNodeOutputMaterial"); out_e.target = "EEVEE"; out_e.location = (900, -150)
        L.new(glow.outputs[0], out_e.inputs["Surface"])
        return mat

    # EEVEE: how lit a white floor is here, against how lit it is with nothing in the way.
    probe = N.new("ShaderNodeBsdfDiffuse"); probe.location = (-500, -300)
    to_rgb = N.new("ShaderNodeShaderToRGB"); to_rgb.location = (-300, -300)
    bw = N.new("ShaderNodeRGBToBW"); bw.location = (-120, -300)
    ratio = N.new("ShaderNodeMath"); ratio.operation = "DIVIDE"; ratio.use_clamp = True; ratio.location = (60, -300)
    L.new(probe.outputs[0], to_rgb.inputs[0])
    L.new(to_rgb.outputs["Color"], bw.inputs[0])
    L.new(bw.outputs[0], ratio.inputs[0])
    L.new(lit_v.outputs[0], ratio.inputs[1])
    shade = N.new("ShaderNodeVectorMath"); shade.operation = "SCALE"; shade.location = (240, -150)
    L.new(env.outputs["Color"], shade.inputs[0])
    L.new(ratio.outputs[0], shade.inputs["Scale"])
    ev = N.new("ShaderNodeEmission"); ev.location = (420, -150)
    L.new(shade.outputs["Vector"], ev.inputs["Color"])
    out_e = N.new("ShaderNodeOutputMaterial"); out_e.target = "EEVEE"; out_e.location = (900, -150)
    L.new(ev.outputs[0], out_e.inputs["Surface"])
    return mat


def _sky_tint(image):
    """The colour of the light falling on the floor, scaled to average 1."""
    import numpy as np
    w, h = image.size
    if not w or not h:
        return (1.0, 1.0, 1.0)
    px = np.empty(w * h * 4, np.float32)
    image.pixels.foreach_get(px)
    px = px.reshape(h, w, 4)[..., :3]
    el = (np.arange(h) + 0.5) / h * math.pi - math.pi / 2
    wgt = np.clip(np.sin(el), 0, None) * np.cos(el)
    c = (px.mean(1) * wgt[:, None]).sum(0) / max(wgt.sum(), 1e-6)
    m = max(float(c.mean()), 1e-6)
    return tuple(float(max(v / m, 0.05)) for v in c)


def _dome_objects(context, hdr, centre, height, radius, rot_z, image=None):
    import bmesh
    scene = context.scene
    for o in [o for o in scene.objects if o.get("camtrack_dome")]:
        bpy.data.objects.remove(o)
    col = bpy.data.collections.get("HDRI dome") or bpy.data.collections.new("HDRI dome")
    if col.name not in scene.collection.children:
        scene.collection.children.link(col)

    eye = bpy.data.objects.new("HDRI capture point", None)
    eye.empty_display_type = "SPHERE"
    eye.empty_display_size = 0.1
    eye.location = centre + Vector((0, 0, height))
    eye["camtrack_dome"] = True
    col.objects.link(eye)

    image = image or bpy.data.images.load(hdr, check_existing=True)
    lit = _estimate_lit(scene)
    wall_mat = _dome_material(DOME_MAT, image, eye, rot_z, lit, False)
    floor_mat = _dome_material(DOME_MAT + " floor", image, eye, rot_z, lit, True, _sky_tint(image))

    def make(name, build, mat):
        bm = bmesh.new()
        build(bm)
        mesh = bpy.data.meshes.new(name)
        bm.to_mesh(mesh)
        bm.free()
        for f in mesh.polygons:
            f.use_smooth = True
        mesh.materials.append(mat)
        o = bpy.data.objects.new(name, mesh)
        o.location = centre
        o["camtrack_dome"] = True
        col.objects.link(o)
        # Seen by the camera and in reflections, but it never blocks or adds light:
        # the world HDRI does the lighting, from the right directions.
        o.visible_diffuse = False
        o.visible_shadow = False
        o.visible_volume_scatter = False
        return o

    def walls(bm):
        bmesh.ops.create_uvsphere(bm, u_segments=96, v_segments=48, radius=radius)
        bmesh.ops.delete(bm, geom=[v for v in bm.verts if v.co.z < -1e-4], context="VERTS")

    def floor(bm):
        # Rings, not a fan: the floor is where the camera looks most.
        rings, segs = 24, 96
        prev = None
        centre_v = bm.verts.new((0, 0, 0))
        for r in range(1, rings + 1):
            rad = radius * (r / rings) ** 2
            ring = [bm.verts.new((rad * math.cos(2 * math.pi * i / segs), rad * math.sin(2 * math.pi * i / segs), 0)) for i in range(segs)]
            for i in range(segs):
                j = (i + 1) % segs
                if prev is None:
                    bm.faces.new((centre_v, ring[i], ring[j]))
                else:
                    bm.faces.new((prev[i], ring[i], ring[j], prev[j]))
            prev = ring

    make("HDRI dome", walls, wall_mat)
    make("HDRI floor", floor, floor_mat)
    if scene.render.engine not in {"CYCLES", _eevee_id()}:
        scene.render.engine = "CYCLES"
    scene.render.film_transparent = False
    return eye


def _world_hdri(scene):
    """The world's HDRI image and its turn round Z, or (None, 0)."""
    world = scene.world
    if not world or not world.node_tree:
        return None, 0.0
    env = next((n for n in world.node_tree.nodes if n.type == "TEX_ENVIRONMENT" and n.image), None)
    if env is None:
        return None, 0.0
    mapping = next((n for n in world.node_tree.nodes if n.type == "MAPPING"), None)
    return env.image, (mapping.inputs["Rotation"].default_value[2] if mapping else 0.0)


def _remove_dome(scene):
    for o in [o for o in scene.objects if o.get("camtrack_dome")]:
        bpy.data.objects.remove(o)


def _dome_toggled(scene, context):
    _remove_dome(scene)
    if not scene.camtrack_dome:
        return
    image, rot_z = _world_hdri(scene)
    if image is None:
        scene["camtrack_dome"] = False
        return
    centre = Vector((0.0, 0.0, 0.0))
    if not scene.get("camtrack_dome_height_set"):
        # A take's HDRI is captured right after the shot, standing where the shot ended.
        root = _root_of(scene.camera) if scene.camera else None
        cam = _take_camera(root) if root else None
        if cam is not None:
            keep = scene.frame_current
            scene.frame_set(scene.frame_end)
            spot = cam.matrix_world.translation.copy()
            scene.frame_set(keep)
            scene["camtrack_dome_height"] = max(0.3, spot.z)
            scene["camtrack_dome_spot"] = (spot.x, spot.y)
    spot = scene.get("camtrack_dome_spot", (0.0, 0.0))
    centre = Vector((spot[0], spot[1], 0.0))
    _dome_objects(context, bpy.path.abspath(image.filepath), centre,
                  scene.camtrack_dome_height, scene.camtrack_dome_size, rot_z, image)


def _dome_height(scene, context):
    scene["camtrack_dome_height_set"] = True
    eye = next((o for o in scene.objects if o.get("camtrack_dome") and o.type == "EMPTY"), None)
    if eye is not None:
        eye.location.z = scene.camtrack_dome_height


def _dome_size(scene, context):
    if scene.camtrack_dome:
        _dome_toggled(scene, context)


class CAMTRACK_OT_load_hdri(bpy.types.Operator, ImportHelper):
    """Light the scene with an HDRI file, as a normal world. Turn on Ground projection to stand objects on its floor"""
    bl_idname = "camtrack.load_hdri"
    bl_label = "Open HDRI"
    bl_options = {"REGISTER", "UNDO"}

    filter_glob: StringProperty(default="*.hdr;*.exr", options={"HIDDEN"})

    def execute(self, context):
        scene = context.scene
        _world_from_hdr(scene, bpy.path.abspath(self.filepath), 0.0)
        if scene.camtrack_dome:
            _dome_toggled(scene, context)
        self.report({"INFO"}, "HDRI loaded as the world")
        return {"FINISHED"}


def _draw_hdri(layout, context):
    scene = context.scene
    box = layout.box()
    box.label(text="HDRI", icon="WORLD_DATA")
    box.operator(CAMTRACK_OT_load_hdri.bl_idname, icon="FILE_IMAGE")
    image, _ = _world_hdri(scene)
    row = box.row()
    row.enabled = image is not None
    row.prop(scene, "camtrack_dome", text="Ground projection", toggle=True, icon="MESH_UVSPHERE")
    if image is None:
        box.label(text="Load an HDRI first", icon="INFO")
    elif scene.camtrack_dome:
        col = box.column(align=True)
        col.prop(scene, "camtrack_dome_height")
        col.prop(scene, "camtrack_dome_size")


class CAMTRACK_PT_panel(bpy.types.Panel):
    bl_label = "Camera Tracker"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tracker"

    def draw(self, context):
        layout = self.layout
        layout.operator(CAMTRACK_OT_import.bl_idname, text="Import take", icon="IMPORT")
        root = _active_root(context)
        if root is None:
            layout.label(text="Pick the zip from the phone app", icon="INFO")
            _draw_hdri(layout, context)
            return
        cam = _take_camera(root)
        row = layout.row()
        row.scale_y = 1.5
        row.operator(CAMTRACK_OT_setup.bl_idname, text="Set up scene", icon="SCENE_DATA")
        row = layout.row(align=True)
        eevee = context.scene.render.engine == _eevee_id()
        op = row.operator(CAMTRACK_OT_engine.bl_idname, text="Cycles", depress=not eevee)
        op.engine = "CYCLES"
        op = row.operator(CAMTRACK_OT_engine.bl_idname, text="EEVEE", depress=eevee)
        op.engine = "EEVEE"
        box = layout.box()
        box.label(text=root.name.replace(" origin", ""), icon="CAMERA_DATA")
        box.prop(root, "location", text="Move take")
        box.prop(root, "scale", text="Scale take")
        if cam is not None:
            col = box.column(align=True)
            col.prop(cam, '["camtrack_smoothing"]', text="Smooth shake (frames)")
            col.prop(cam, '["camtrack_offset"]', text="Frame offset")
            col.operator(CAMTRACK_OT_rekey.bl_idname, text="Apply smoothing and offset")

        box = layout.box()
        box.label(text="Make it look real", icon="SHADING_RENDERED")
        box.operator(CAMTRACK_OT_shadow_catcher.bl_idname, icon="MESH_PLANE")
        box.operator(CAMTRACK_OT_make_catcher.bl_idname, icon="RESTRICT_SELECT_OFF")
        row = box.row(align=True)
        op = row.operator(CAMTRACK_OT_project.bl_idname, text="Project frame onto selected", icon="IMAGE_PLANE")
        op.follow = False
        op = row.operator(CAMTRACK_OT_project.bl_idname, text="", icon="FILE_MOVIE")
        op.follow = True
        mat = _find_catcher(context.scene)
        if mat and context.scene.render.engine == _eevee_id():
            col = box.column(align=True)
            col.prop(mat.node_tree.nodes["Shadow strength"].outputs[0], "default_value", text="EEVEE shadow strength", slider=True)
            col.operator(CAMTRACK_OT_calibrate.bl_idname, icon="FILE_REFRESH")
        box.operator(CAMTRACK_OT_room_light.bl_idname, icon="WORLD")
        box.operator(CAMTRACK_OT_match_light.bl_idname, icon="LIGHT_SUN")
        box.operator(CAMTRACK_OT_room_mesh.bl_idname, icon="MESH_ICOSPHERE")
        box.operator(CAMTRACK_OT_composite.bl_idname, icon="NODE_COMPOSITING")
        _draw_hdri(layout, context)

        markers = [c for c in root.children if c.type == "EMPTY" and c.name.startswith("Marker")]
        if markers:
            box = layout.box()
            box.label(text="Stand selected objects on", icon="EMPTY_AXIS")
            row = box.row(align=True)
            for m in markers[:8]:
                op = row.operator(CAMTRACK_OT_to_marker.bl_idname, text=m.name.replace("Marker ", "M"))
                op.marker = m.name


def _menu_import(self, context):
    self.layout.operator(CAMTRACK_OT_import.bl_idname, text="Camera Tracker take (.zip, .json)")


classes = (
    CAMTRACK_OT_import,
    CAMTRACK_OT_rekey,
    CAMTRACK_OT_shadow_catcher,
    CAMTRACK_OT_composite,
    CAMTRACK_OT_match_light,
    CAMTRACK_OT_to_marker,
    CAMTRACK_OT_room_light,
    CAMTRACK_OT_room_mesh,
    CAMTRACK_OT_setup,
    CAMTRACK_OT_make_catcher,
    CAMTRACK_OT_calibrate,
    CAMTRACK_OT_engine,
    CAMTRACK_OT_project,
    CAMTRACK_OT_load_hdri,
    CAMTRACK_PT_panel,
)


def register():
    for c in classes:
        bpy.utils.register_class(c)
    S = bpy.types.Scene
    S.camtrack_dome = BoolProperty(name="Ground projection", default=False, update=_dome_toggled,
                                   description="Put the world HDRI on a dome with a real floor, seen from the height it was captured at, so objects stand on its ground and cast shadows")
    S.camtrack_dome_height = FloatProperty(name="Camera height", default=1.4, min=0.05, max=50, unit="LENGTH", update=_dome_height,
                                           description="How high the camera was when the HDRI was captured. If the ground looks too big, raise it")
    S.camtrack_dome_size = FloatProperty(name="Floor size", default=30.0, min=2, max=1000, unit="LENGTH", update=_dome_size,
                                         description="Radius of the floor before it turns into the dome")
    bpy.types.TOPBAR_MT_file_import.append(_menu_import)


def unregister():
    bpy.types.TOPBAR_MT_file_import.remove(_menu_import)
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
    for n in ("camtrack_dome", "camtrack_dome_height", "camtrack_dome_size"):
        delattr(bpy.types.Scene, n)
