"""Camera Tracker for Blender: imports a take recorded with the Camera Tracker
Android app (video + ARCore camera path) as a ready matched camera.

The phone writes ARCore's world: metres, +Y up, the camera looking down its -Z
with +Y up in the picture, which is already Blender's camera convention. So the
whole take lives under one root empty that turns Y up into Z up, and moving,
turning or scaling that root lines the take up with any scene.
"""

bl_info = {
    "name": "Camera Tracker",
    "author": "Akshay C P",
    "version": (1, 0, 0),
    "blender": (4, 2, 0),
    "location": "File > Import > Camera Tracker take, and the Tracker tab in the 3D view sidebar",
    "description": "Import phone camera tracks from the Camera Tracker Android app",
    "category": "Import-Export",
}

import json
import math
import os
import zipfile

import bpy
from bpy.props import BoolProperty, FloatProperty, IntProperty, StringProperty
from bpy_extras.io_utils import ImportHelper
from mathutils import Matrix, Quaternion, Vector

ROOT_KEY = "camtrack_root"


# --------------------------------------------------------------------- reading

def _find_track(path):
    """Returns the track.json for a zip, a folder or the json itself."""
    path = bpy.path.abspath(path)
    if path.lower().endswith(".zip"):
        base = os.path.splitext(path)[0]
        with zipfile.ZipFile(path) as z:
            names = [n for n in z.namelist() if n.endswith("track.json")]
            if not names:
                raise ValueError("That zip has no track.json in it")
            # Unpack next to the zip so the video stays where the .blend can find it.
            target = os.path.dirname(path)
            top = names[0].split("/")[0] if "/" in names[0] else None
            if top is None:
                target = base
            z.extractall(target)
            return os.path.join(target, names[0])
    if os.path.isdir(path):
        path = os.path.join(path, "track.json")
    if not os.path.exists(path):
        raise ValueError("No track.json found")
    return path


def _load(path):
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    if data.get("format") != "camera-tracker":
        raise ValueError("This is not a Camera Tracker take")
    return data


def _pose_matrix(p):
    """[px, py, pz, qx, qy, qz, qw] in ARCore order to a 4x4."""
    q = Quaternion((p[6], p[3], p[4], p[5]))
    m = q.to_matrix().to_4x4()
    m.translation = Vector((p[0], p[1], p[2]))
    return m


# ------------------------------------------------------------------ animation

def _fcurves(obj):
    """All F-curves of an object's action, on both the 5.x slotted API and the old one."""
    ad = obj.animation_data
    if ad is None or ad.action is None:
        return []
    action = ad.action
    slot = getattr(ad, "action_slot", None)
    if slot is not None:
        try:
            from bpy_extras import anim_utils
            bag = anim_utils.action_get_channelbag_for_slot(action, slot)
            if bag is not None:
                return list(bag.fcurves)
        except (ImportError, AttributeError):
            pass
    return list(getattr(action, "fcurves", []))


def _bake(obj, path, values_per_frame, start):
    """Writes one key per frame for every channel of `path` in a single pass.

    values_per_frame is a list of tuples (one tuple per frame)."""
    n = len(values_per_frame)
    if n == 0:
        return
    width = len(values_per_frame[0])
    obj.keyframe_insert(path, frame=start)
    curves = {fc.array_index: fc for fc in _fcurves(obj) if fc.data_path == path}
    for i in range(width):
        fc = curves.get(i)
        if fc is None:
            continue
        fc.keyframe_points.clear()
        fc.keyframe_points.add(n)
        co = [0.0] * (2 * n)
        for f in range(n):
            co[2 * f] = start + f
            co[2 * f + 1] = values_per_frame[f][i]
        fc.keyframe_points.foreach_set("co", co)
        fc.keyframe_points.foreach_set("interpolation", [1] * n)  # LINEAR
        fc.update()


def _smoothed(poses, ok, window):
    """Centred moving average on positions, normalised average on rotations.

    Frames where tracking was lost hold the last good pose instead."""
    n = len(poses)
    good = list(poses)
    last = None
    for i in range(n):
        if ok[i]:
            last = poses[i]
        elif last is not None:
            good[i] = last
    if window <= 0:
        return good
    out = []
    for i in range(n):
        a, b = max(0, i - window), min(n, i + window + 1)
        loc = Vector()
        q0 = Quaternion((good[i][6], good[i][3], good[i][4], good[i][5]))
        qs = Vector((0, 0, 0, 0))
        for j in range(a, b):
            p = good[j]
            loc += Vector(p[:3])
            q = Quaternion((p[6], p[3], p[4], p[5]))
            if q.dot(q0) < 0:
                q.negate()
            qs += Vector(q)
        loc /= (b - a)
        q = Quaternion(qs).normalized()
        out.append([loc.x, loc.y, loc.z, q.x, q.y, q.z, q.w])
    return out


def _key_camera(cam_obj, data, smoothing, offset):
    frames = data["frames"]
    poses = [f[2:9] for f in frames]
    ok = [bool(f[1]) for f in frames]
    poses = _smoothed(poses, ok, smoothing)

    locs, quats = [], []
    prev = None
    for p in poses:
        q = Quaternion((p[6], p[3], p[4], p[5]))
        # Keep neighbouring quaternions on the same side so interpolation never spins.
        if prev is not None and q.dot(prev) < 0:
            q.negate()
        prev = q
        locs.append((p[0], p[1], p[2]))
        quats.append((q.w, q.x, q.y, q.z))

    if cam_obj.animation_data:
        cam_obj.animation_data_clear()
    cam_obj.rotation_mode = "QUATERNION"
    start = 1 + offset
    _bake(cam_obj, "location", locs, start)
    _bake(cam_obj, "rotation_quaternion", quats, start)

    # Lens: one row unless the focus moved.
    cam = cam_obj.data
    if cam.animation_data:
        cam.animation_data_clear()
    lens_rows = data.get("lens") or []
    w, h = data["width"], data["height"]
    big = max(w, h)
    cam.sensor_fit = "AUTO"
    cam.sensor_width = 36.0
    for row in lens_rows:
        frame, fx, fy, cx, cy = row
        f_big = fx if w >= h else fy
        cam.lens = f_big * cam.sensor_width / big
        # Blender shifts the frame in units of its longer side.
        cam.shift_x = (w / 2.0 - cx) / big
        cam.shift_y = (cy - h / 2.0) / big
        if len(lens_rows) > 1:
            cam.keyframe_insert("lens", frame=start + int(frame))
            cam.keyframe_insert("shift_x", frame=start + int(frame))
            cam.keyframe_insert("shift_y", frame=start + int(frame))


# --------------------------------------------------------------- scene build

def _collection(name, parent):
    col = bpy.data.collections.new(name)
    parent.children.link(col)
    return col


def _link(obj, col):
    col.objects.link(obj)
    return obj


def _plane_mesh(name, polygon):
    """An ARCore plane polygon is (x, z) pairs in the plane's own space, y = 0."""
    verts = [(polygon[i], 0.0, polygon[i + 1]) for i in range(0, len(polygon) - 1, 2)]
    mesh = bpy.data.meshes.new(name)
    if len(verts) >= 3:
        mesh.from_pydata(verts, [], [list(range(len(verts)))])
    mesh.update()
    return mesh


def _main_floor(data):
    floors = [p for p in data.get("planes", []) if p["type"] == "floor"]
    if not floors:
        return None
    return max(floors, key=lambda p: p["extent"][0] * p["extent"][1])


def build_take(context, track_path, floor_to_zero=True, marker_origin=True, point_cloud=True):
    data = _load(track_path)
    folder = os.path.dirname(track_path)
    name = os.path.basename(folder) or "Take"
    scene = context.scene
    n = len(data["frames"])
    w, h, fps = data["width"], data["height"], data["fps"]

    scene.render.resolution_x = w
    scene.render.resolution_y = h
    scene.render.resolution_percentage = 100
    scene.render.fps = int(fps)
    scene.render.fps_base = 1.0
    scene.frame_start = 1
    scene.frame_end = n
    scene.frame_set(1)

    col = _collection(name, scene.collection)

    # The root: ARCore's Y up turned into Blender's Z up.
    root = _link(bpy.data.objects.new(name + " origin", None), col)
    root.empty_display_type = "ARROWS"
    root.empty_display_size = 0.25
    root[ROOT_KEY] = bpy.path.relpath(track_path) if bpy.data.filepath else track_path
    root.rotation_euler = (math.radians(90), 0, 0)

    def child(obj):
        _link(obj, col)
        obj.parent = root
        return obj

    # Camera.
    cam_data = bpy.data.cameras.new(name + " camera")
    cam_data.clip_start = 0.02
    cam_data.clip_end = 500
    cam = child(bpy.data.objects.new(name + " camera", cam_data))
    cam["camtrack_smoothing"] = 0
    cam["camtrack_offset"] = 0
    _key_camera(cam, data, 0, 0)
    scene.camera = cam

    # The plate behind the camera.
    video = os.path.join(folder, data.get("video", "shot.mp4"))
    if os.path.exists(video):
        clip = bpy.data.movieclips.load(video, check_existing=True)
        clip.frame_start = 1
        scene.active_clip = clip
        cam_data.show_background_images = True
        bg = cam_data.background_images.new()
        bg.source = "MOVIE_CLIP"
        bg.clip = clip
        bg.alpha = 1.0
        bg.display_depth = "BACK"
        if hasattr(bg, "use_camera_clip"):
            bg.use_camera_clip = False

    # Markers the user tapped on the phone.
    markers = []
    for m in data.get("markers", []):
        e = child(bpy.data.objects.new(m["name"], None))
        e.empty_display_type = "PLAIN_AXES"
        e.empty_display_size = 0.08
        e.matrix_parent_inverse = Matrix.Identity(4)
        e.matrix_basis = _pose_matrix(m["pose"])
        markers.append(e)

    # Surfaces ARCore found, as wire references that never render.
    counts = {}
    for p in data.get("planes", []):
        kind = p["type"].capitalize()
        counts[kind] = counts.get(kind, 0) + 1
        mesh = _plane_mesh(f"{kind} {counts[kind]}", p.get("polygon", []))
        o = child(bpy.data.objects.new(f"{kind} {counts[kind]}", mesh))
        o.matrix_basis = _pose_matrix(p["pose"])
        o.display_type = "WIRE"
        o.hide_render = True
        o["camtrack_plane"] = p["type"]

    # Feature points, handy to see where real surfaces were.
    pts = data.get("points") or []
    if point_cloud and pts:
        verts = [(pts[i], pts[i + 1], pts[i + 2]) for i in range(0, len(pts) - 2, 3)]
        mesh = bpy.data.meshes.new(name + " points")
        mesh.from_pydata(verts, [], [])
        o = child(bpy.data.objects.new(name + " points", mesh))
        o.hide_render = True

    # Put the scene's origin somewhere useful: the first marker, else the floor.
    # Across from the first marker (else the floor's middle), height from the floor
    # (else that marker), so a marker tapped on a table still leaves the floor at 0.
    floor = _main_floor(data)
    first = Vector(data["markers"][0]["pose"][:3]) if data.get("markers") else None
    anchor = Vector((0.0, 0.0, 0.0))
    if marker_origin and first is not None:
        anchor.x, anchor.z = first.x, first.z
    elif floor:
        anchor.x, anchor.z = floor["pose"][0], floor["pose"][2]
    if floor_to_zero and floor:
        anchor.y = floor["pose"][1]
    elif first is not None and marker_origin:
        anchor.y = first.y
    # ARCore (x, y, z) lands at Blender (x, -z, y) under the root.
    root.location = (-anchor.x, anchor.z, -anchor.y)
    root["camtrack_floor_y"] = floor["pose"][1] if floor else anchor.y

    for o in context.view_layer.objects:
        o.select_set(False)
    root.select_set(True)
    context.view_layer.objects.active = root
    return root


def _root_of(obj):
    while obj is not None:
        if ROOT_KEY in obj:
            return obj
        obj = obj.parent
    return None


def _active_root(context):
    root = _root_of(context.active_object)
    if root:
        return root
    cam = context.scene.camera
    return _root_of(cam)


def _take_camera(root):
    for c in root.children:
        if c.type == "CAMERA":
            return c
    return None


# ------------------------------------------------------------------ operators

class CAMTRACK_OT_import(bpy.types.Operator, ImportHelper):
    """Import a take from the Camera Tracker phone app (zip or track.json)"""
    bl_idname = "camtrack.import_take"
    bl_label = "Import Camera Tracker take"
    bl_options = {"REGISTER", "UNDO"}

    filter_glob: StringProperty(default="*.zip;*.json", options={"HIDDEN"})
    floor_to_zero: BoolProperty(name="Floor at Z = 0", default=True,
                                description="Move the take so the floor the phone found sits at Z = 0")
    marker_origin: BoolProperty(name="Marker 1 is the origin", default=True,
                                description="Put the first marker you tapped at the world origin")
    point_cloud: BoolProperty(name="Feature points", default=True,
                              description="Add the points the phone tracked, as a reference mesh")

    def execute(self, context):
        try:
            track = _find_track(self.filepath)
            build_take(context, track, self.floor_to_zero, self.marker_origin, self.point_cloud)
        except Exception as e:
            self.report({"ERROR"}, str(e))
            return {"CANCELLED"}
        self.report({"INFO"}, "Take imported. Press Numpad 0 to look through the phone")
        return {"FINISHED"}


class CAMTRACK_OT_rekey(bpy.types.Operator):
    """Re-bake the camera with smoothing and a frame offset, from the original track"""
    bl_idname = "camtrack.rekey"
    bl_label = "Apply"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        root = _active_root(context)
        cam = _take_camera(root) if root else None
        if cam is None:
            self.report({"ERROR"}, "Select something from an imported take first")
            return {"CANCELLED"}
        path = bpy.path.abspath(root[ROOT_KEY])
        try:
            data = _load(path)
        except Exception as e:
            self.report({"ERROR"}, f"Can't read the track again: {e}")
            return {"CANCELLED"}
        _key_camera(cam, data, int(cam.get("camtrack_smoothing", 0)), int(cam.get("camtrack_offset", 0)))
        return {"FINISHED"}


class CAMTRACK_OT_shadow_catcher(bpy.types.Operator):
    """Add a shadow catcher on the floor so objects cast shadows onto the real ground"""
    bl_idname = "camtrack.shadow_catcher"
    bl_label = "Add shadow catcher"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        root = _active_root(context)
        if root is None:
            self.report({"ERROR"}, "Select something from an imported take first")
            return {"CANCELLED"}
        data = _load(bpy.path.abspath(root[ROOT_KEY]))
        floor = _main_floor(data)
        size = 6.0
        if floor:
            size = max(4.0, 2.5 * max(floor["extent"]))
            y = floor["pose"][1]
            centre = Vector((floor["pose"][0], y, floor["pose"][2]))
        else:
            y = root.get("camtrack_floor_y", 0.0)
            centre = Vector((0.0, y, 0.0))
        bpy.ops.mesh.primitive_plane_add(size=size)
        plane = context.active_object
        plane.name = "Shadow catcher"
        for c in plane.users_collection:
            c.objects.unlink(plane)
        root.users_collection[0].objects.link(plane)
        plane.parent = root
        # A plane is made flat in XY; in the root's Y up space the floor is XZ.
        plane.matrix_basis = Matrix.Translation(centre) @ Matrix.Rotation(math.radians(-90), 4, "X")
        plane.is_shadow_catcher = True
        context.scene.render.engine = "CYCLES"
        context.scene.render.film_transparent = True
        self.report({"INFO"}, "Shadow catcher added. Use Set up composite to render over the video")
        return {"FINISHED"}


def _compositor_tree(scene):
    """The compositing node tree on 5.x (a node group) and on 4.x (scene.node_tree)."""
    if hasattr(scene, "compositing_node_group"):
        tree = scene.compositing_node_group
        if tree is None:
            tree = bpy.data.node_groups.new("Camera Tracker composite", "CompositorNodeTree")
            scene.compositing_node_group = tree
        return tree, True
    scene.use_nodes = True
    return scene.node_tree, False


class CAMTRACK_OT_composite(bpy.types.Operator):
    """Render the 3D layer over the phone video, with shadows, in one click"""
    bl_idname = "camtrack.composite"
    bl_label = "Set up composite"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene = context.scene
        clip = scene.active_clip
        if clip is None:
            self.report({"ERROR"}, "No video found. Import a take first")
            return {"CANCELLED"}
        scene.render.film_transparent = True
        if scene.render.engine not in {"CYCLES", "BLENDER_EEVEE_NEXT", "BLENDER_EEVEE"}:
            scene.render.engine = "CYCLES"
        tree, is_group = _compositor_tree(scene)
        tree.nodes.clear()
        rl = tree.nodes.new("CompositorNodeRLayers")
        rl.location = (-300, 200)
        mc = tree.nodes.new("CompositorNodeMovieClip")
        mc.clip = clip
        mc.location = (-300, -150)
        over = tree.nodes.new("CompositorNodeAlphaOver")
        over.location = (50, 50)
        # Background goes in the first image socket, the render on top in the second.
        image_inputs = [s for s in over.inputs if s.type == "RGBA"]
        # Fit the plate to the render size, so a 50% preview render still lines up.
        fit = tree.nodes.new("CompositorNodeScale")
        fit.location = (-120, -150)
        if "Type" in fit.inputs:  # 5.x: options are menu sockets
            try:
                fit.inputs["Type"].default_value = "Render Size"
                fit.inputs["Frame Type"].default_value = "Fit"
            except (TypeError, KeyError):
                pass
        else:
            fit.space = "RENDER_SIZE"
            fit.frame_method = "FIT"
        tree.links.new(mc.outputs["Image"], fit.inputs[0])
        tree.links.new(fit.outputs[0], image_inputs[0])
        tree.links.new(rl.outputs["Image"], image_inputs[1])
        if is_group:
            if not any(s.in_out == "OUTPUT" for s in tree.interface.items_tree if getattr(s, "item_type", "") == "SOCKET"):
                tree.interface.new_socket("Image", in_out="OUTPUT", socket_type="NodeSocketColor")
            out = tree.nodes.new("NodeGroupOutput")
            out.location = (300, 50)
            tree.links.new(over.outputs[0], out.inputs[0])
        else:
            out = tree.nodes.new("CompositorNodeComposite")
            out.location = (300, 50)
            tree.links.new(over.outputs[0], out.inputs[0])
        viewer = tree.nodes.new("CompositorNodeViewer")
        viewer.location = (300, -150)
        tree.links.new(over.outputs[0], viewer.inputs[0])
        self.report({"INFO"}, "Composite ready. F12 renders your objects over the video")
        return {"FINISHED"}


class CAMTRACK_OT_match_light(bpy.types.Operator):
    """Add a sun pointing the way the real main light came from, as the phone measured it"""
    bl_idname = "camtrack.match_light"
    bl_label = "Match the real light"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        root = _active_root(context)
        if root is None:
            self.report({"ERROR"}, "Select something from an imported take first")
            return {"CANCELLED"}
        data = _load(bpy.path.abspath(root[ROOT_KEY]))
        light = data.get("light")
        if not light:
            self.report({"WARNING"}, "This phone did not measure the light for this take")
            return {"CANCELLED"}
        d = Vector(light["direction"]).normalized()
        c = Vector(light["intensity"])
        peak = max(c.x, c.y, c.z, 1e-4)
        sun_data = bpy.data.lights.new("Real light", "SUN")
        sun_data.color = (c.x / peak, c.y / peak, c.z / peak)
        sun_data.energy = max(0.5, min(10.0, peak * 3.0))
        sun_data.angle = math.radians(8)
        sun = bpy.data.objects.new("Real light", sun_data)
        root.users_collection[0].objects.link(sun)
        sun.parent = root
        # A sun shines down its -Z; ARCore's direction points towards the light.
        sun.matrix_basis = d.to_track_quat("Z", "Y").to_matrix().to_4x4()
        sun.location = Vector((0, 1.5, 0))

        sh = light.get("harmonics")
        if sh and len(sh) >= 3:
            world = context.scene.world or bpy.data.worlds.new("World")
            context.scene.world = world
            ambient = [max(0.0, v * 0.886) for v in sh[:3]]
            if hasattr(world, "use_nodes"):
                world.use_nodes = True
            bg = next((n for n in world.node_tree.nodes if n.type == "BACKGROUND"), None) if world.node_tree else None
            if bg:
                bg.inputs["Color"].default_value = (*ambient, 1.0)
                bg.inputs["Strength"].default_value = 1.0
            else:
                world.color = ambient
        self.report({"INFO"}, "Sun added from the light the phone saw")
        return {"FINISHED"}


class CAMTRACK_OT_to_marker(bpy.types.Operator):
    """Stand the selected objects on a marker you tapped on the phone"""
    bl_idname = "camtrack.to_marker"
    bl_label = "Put selection on marker"
    bl_options = {"REGISTER", "UNDO"}

    marker: StringProperty()

    def execute(self, context):
        target = bpy.data.objects.get(self.marker)
        if target is None:
            return {"CANCELLED"}
        spot = target.matrix_world.translation.copy()
        moved = 0
        for o in context.selected_objects:
            if o == target or _root_of(o) is not None:
                continue
            o.location = spot if o.parent is None else o.parent.matrix_world.inverted() @ spot
            moved += 1
        if moved == 0:
            self.report({"WARNING"}, "Select your own objects first, then pick the marker")
        return {"FINISHED"}


# ---------------------------------------------------------------------- panel

class CAMTRACK_PT_panel(bpy.types.Panel):
    bl_label = "Camera Tracker"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tracker"

    def draw(self, context):
        layout = self.layout
        layout.operator(CAMTRACK_OT_import.bl_idname, text="Import take", icon="IMPORT")
        root = _active_root(context)
        if root is None:
            layout.label(text="Pick the zip from the phone app", icon="INFO")
            return
        cam = _take_camera(root)
        box = layout.box()
        box.label(text=root.name.replace(" origin", ""), icon="CAMERA_DATA")
        box.prop(root, "location", text="Move take")
        box.prop(root, "scale", text="Scale take")
        if cam is not None:
            col = box.column(align=True)
            col.prop(cam, '["camtrack_smoothing"]', text="Smooth shake (frames)")
            col.prop(cam, '["camtrack_offset"]', text="Frame offset")
            col.operator(CAMTRACK_OT_rekey.bl_idname, text="Apply smoothing and offset")

        box = layout.box()
        box.label(text="Make it look real", icon="SHADING_RENDERED")
        box.operator(CAMTRACK_OT_shadow_catcher.bl_idname, icon="MESH_PLANE")
        box.operator(CAMTRACK_OT_match_light.bl_idname, icon="LIGHT_SUN")
        box.operator(CAMTRACK_OT_composite.bl_idname, icon="NODE_COMPOSITING")

        markers = [c for c in root.children if c.type == "EMPTY" and c.name.startswith("Marker")]
        if markers:
            box = layout.box()
            box.label(text="Stand selected objects on", icon="EMPTY_AXIS")
            row = box.row(align=True)
            for m in markers[:8]:
                op = row.operator(CAMTRACK_OT_to_marker.bl_idname, text=m.name.replace("Marker ", "M"))
                op.marker = m.name


def _menu_import(self, context):
    self.layout.operator(CAMTRACK_OT_import.bl_idname, text="Camera Tracker take (.zip, .json)")


classes = (
    CAMTRACK_OT_import,
    CAMTRACK_OT_rekey,
    CAMTRACK_OT_shadow_catcher,
    CAMTRACK_OT_composite,
    CAMTRACK_OT_match_light,
    CAMTRACK_OT_to_marker,
    CAMTRACK_PT_panel,
)


def register():
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.TOPBAR_MT_file_import.append(_menu_import)


def unregister():
    bpy.types.TOPBAR_MT_file_import.remove(_menu_import)
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
