"""Camera Tracker for Blender: imports a take recorded with the Camera Tracker
Android app (video + ARCore camera path) as a ready matched camera.

The phone writes ARCore's world: metres, +Y up, the camera looking down its -Z
with +Y up in the picture, which is already Blender's camera convention. So the
whole take lives under one root empty that turns Y up into Z up, and moving,
turning or scaling that root lines the take up with any scene.
"""

bl_info = {
    "name": "Camera Tracker",
    "author": "Akshay C P",
    "version": (1, 5, 0),
    "blender": (4, 2, 0),
    "location": "File > Import > Camera Tracker take, and the Tracker tab in the 3D view sidebar",
    "description": "Import phone camera tracks from the Camera Tracker Android app",
    "category": "Import-Export",
}

import json
import math
import os
import zipfile

import bpy
from bpy.props import BoolProperty, FloatProperty, IntProperty, StringProperty
from bpy_extras.io_utils import ImportHelper
from mathutils import Matrix, Quaternion, Vector

ROOT_KEY = "camtrack_root"


# --------------------------------------------------------------------- reading

def _find_track(path):
    """Returns the track.json for a zip, a folder or the json itself."""
    path = bpy.path.abspath(path)
    if path.lower().endswith(".zip"):
        base = os.path.splitext(path)[0]
        with zipfile.ZipFile(path) as z:
            names = [n for n in z.namelist() if n.endswith("track.json")]
            if not names:
                raise ValueError("That zip has no track.json in it")
            # Unpack next to the zip so the video stays where the .blend can find it.
            target = os.path.dirname(path)
            top = names[0].split("/")[0] if "/" in names[0] else None
            if top is None:
                target = base
            z.extractall(target)
            return os.path.join(target, names[0])
    if os.path.isdir(path):
        path = os.path.join(path, "track.json")
    if not os.path.exists(path):
        raise ValueError("No track.json found")
    return path


def _load(path):
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    if data.get("format") != "camera-tracker":
        raise ValueError("This is not a Camera Tracker take")
    return data


def _pose_matrix(p):
    """[px, py, pz, qx, qy, qz, qw] in ARCore order to a 4x4."""
    q = Quaternion((p[6], p[3], p[4], p[5]))
    m = q.to_matrix().to_4x4()
    m.translation = Vector((p[0], p[1], p[2]))
    return m


# ------------------------------------------------------------------ animation

def _fcurves(obj):
    """All F-curves of an object's action, on both the 5.x slotted API and the old one."""
    ad = obj.animation_data
    if ad is None or ad.action is None:
        return []
    action = ad.action
    slot = getattr(ad, "action_slot", None)
    if slot is not None:
        try:
            from bpy_extras import anim_utils
            bag = anim_utils.action_get_channelbag_for_slot(action, slot)
            if bag is not None:
                return list(bag.fcurves)
        except (ImportError, AttributeError):
            pass
    return list(getattr(action, "fcurves", []))


def _bake(obj, path, values_per_frame, start):
    """Writes one key per frame for every channel of `path` in a single pass.

    values_per_frame is a list of tuples (one tuple per frame)."""
    n = len(values_per_frame)
    if n == 0:
        return
    width = len(values_per_frame[0])
    obj.keyframe_insert(path, frame=start)
    curves = {fc.array_index: fc for fc in _fcurves(obj) if fc.data_path == path}
    for i in range(width):
        fc = curves.get(i)
        if fc is None:
            continue
        fc.keyframe_points.clear()
        fc.keyframe_points.add(n)
        co = [0.0] * (2 * n)
        for f in range(n):
            co[2 * f] = start + f
            co[2 * f + 1] = values_per_frame[f][i]
        fc.keyframe_points.foreach_set("co", co)
        fc.keyframe_points.foreach_set("interpolation", [1] * n)  # LINEAR
        fc.update()


def _smoothed(poses, ok, window):
    """Centred moving average on positions, normalised average on rotations.

    Frames where tracking was lost hold the last good pose instead."""
    n = len(poses)
    good = list(poses)
    last = None
    for i in range(n):
        if ok[i]:
            last = poses[i]
        elif last is not None:
            good[i] = last
    if window <= 0:
        return good
    out = []
    for i in range(n):
        a, b = max(0, i - window), min(n, i + window + 1)
        loc = Vector()
        q0 = Quaternion((good[i][6], good[i][3], good[i][4], good[i][5]))
        qs = Vector((0, 0, 0, 0))
        for j in range(a, b):
            p = good[j]
            loc += Vector(p[:3])
            q = Quaternion((p[6], p[3], p[4], p[5]))
            if q.dot(q0) < 0:
                q.negate()
            qs += Vector(q)
        loc /= (b - a)
        q = Quaternion(qs).normalized()
        out.append([loc.x, loc.y, loc.z, q.x, q.y, q.z, q.w])
    return out


def _key_camera(cam_obj, data, smoothing, offset):
    frames = data["frames"]
    poses = [f[2:9] for f in frames]
    ok = [bool(f[1]) for f in frames]
    poses = _smoothed(poses, ok, smoothing)

    locs, quats = [], []
    prev = None
    for p in poses:
        q = Quaternion((p[6], p[3], p[4], p[5]))
        # Keep neighbouring quaternions on the same side so interpolation never spins.
        if prev is not None and q.dot(prev) < 0:
            q.negate()
        prev = q
        locs.append((p[0], p[1], p[2]))
        quats.append((q.w, q.x, q.y, q.z))

    if cam_obj.animation_data:
        cam_obj.animation_data_clear()
    cam_obj.rotation_mode = "QUATERNION"
    start = 1 + offset
    _bake(cam_obj, "location", locs, start)
    _bake(cam_obj, "rotation_quaternion", quats, start)

    # Lens: one row unless the focus moved.
    cam = cam_obj.data
    if cam.animation_data:
        cam.animation_data_clear()
    lens_rows = data.get("lens") or []
    w, h = data["width"], data["height"]
    big = max(w, h)
    cam.sensor_fit = "AUTO"
    cam.sensor_width = 36.0
    for row in lens_rows:
        frame, fx, fy, cx, cy = row
        f_big = fx if w >= h else fy
        cam.lens = f_big * cam.sensor_width / big
        # Blender shifts the frame in units of its longer side.
        cam.shift_x = (w / 2.0 - cx) / big
        cam.shift_y = (cy - h / 2.0) / big
        if len(lens_rows) > 1:
            cam.keyframe_insert("lens", frame=start + int(frame))
            cam.keyframe_insert("shift_x", frame=start + int(frame))
            cam.keyframe_insert("shift_y", frame=start + int(frame))


# --------------------------------------------------------------- scene build

def _collection(name, parent):
    col = bpy.data.collections.new(name)
    parent.children.link(col)
    return col


def _link(obj, col):
    col.objects.link(obj)
    return obj


def _plane_mesh(name, polygon):
    """An ARCore plane polygon is (x, z) pairs in the plane's own space, y = 0."""
    verts = [(polygon[i], 0.0, polygon[i + 1]) for i in range(0, len(polygon) - 1, 2)]
    mesh = bpy.data.meshes.new(name)
    if len(verts) >= 3:
        mesh.from_pydata(verts, [], [list(range(len(verts)))])
    mesh.update()
    return mesh


def _main_floor(data):
    floors = [p for p in data.get("planes", []) if p["type"] == "floor"]
    if not floors:
        return None
    return max(floors, key=lambda p: p["extent"][0] * p["extent"][1])


def build_take(context, track_path, floor_to_zero=True, marker_origin=True, point_cloud=True):
    data = _load(track_path)
    folder = os.path.dirname(track_path)
    name = os.path.basename(folder) or "Take"
    scene = context.scene
    n = len(data["frames"])
    w, h, fps = data["width"], data["height"], data["fps"]

    scene.render.resolution_x = w
    scene.render.resolution_y = h
    scene.render.resolution_percentage = 100
    scene.render.fps = int(fps)
    scene.render.fps_base = 1.0
    scene.frame_start = 1
    scene.frame_end = n
    scene.frame_set(1)

    col = _collection(name, scene.collection)

    # The root: ARCore's Y up turned into Blender's Z up.
    root = _link(bpy.data.objects.new(name + " origin", None), col)
    root.empty_display_type = "ARROWS"
    root.empty_display_size = 0.25
    root[ROOT_KEY] = bpy.path.relpath(track_path) if bpy.data.filepath else track_path
    root.rotation_euler = (math.radians(90), 0, 0)

    def child(obj):
        _link(obj, col)
        obj.parent = root
        return obj

    # Camera.
    cam_data = bpy.data.cameras.new(name + " camera")
    cam_data.clip_start = 0.02
    cam_data.clip_end = 500
    cam = child(bpy.data.objects.new(name + " camera", cam_data))
    cam["camtrack_smoothing"] = 0
    cam["camtrack_offset"] = 0
    _key_camera(cam, data, 0, 0)
    scene.camera = cam

    # The plate behind the camera.
    video = os.path.join(folder, data.get("video", "shot.mp4"))
    if os.path.exists(video):
        clip = bpy.data.movieclips.load(video, check_existing=True)
        clip.frame_start = 1
        scene.active_clip = clip
        cam_data.show_background_images = True
        bg = cam_data.background_images.new()
        bg.source = "MOVIE_CLIP"
        bg.clip = clip
        bg.alpha = 1.0
        bg.display_depth = "BACK"
        if hasattr(bg, "use_camera_clip"):
            bg.use_camera_clip = False

    # Markers the user tapped on the phone.
    markers = []
    for m in data.get("markers", []):
        e = child(bpy.data.objects.new(m["name"], None))
        e.empty_display_type = "PLAIN_AXES"
        e.empty_display_size = 0.08
        e.matrix_parent_inverse = Matrix.Identity(4)
        e.matrix_basis = _pose_matrix(m["pose"])
        markers.append(e)

    # Surfaces ARCore found, as wire references that never render.
    counts = {}
    for p in data.get("planes", []):
        kind = p["type"].capitalize()
        counts[kind] = counts.get(kind, 0) + 1
        mesh = _plane_mesh(f"{kind} {counts[kind]}", p.get("polygon", []))
        o = child(bpy.data.objects.new(f"{kind} {counts[kind]}", mesh))
        o.matrix_basis = _pose_matrix(p["pose"])
        o.display_type = "WIRE"
        o.hide_render = True
        o["camtrack_plane"] = p["type"]

    # Feature points, handy to see where real surfaces were.
    pts = data.get("points") or []
    if point_cloud and pts:
        verts = [(pts[i], pts[i + 1], pts[i + 2]) for i in range(0, len(pts) - 2, 3)]
        mesh = bpy.data.meshes.new(name + " points")
        mesh.from_pydata(verts, [], [])
        o = child(bpy.data.objects.new(name + " points", mesh))
        o.hide_render = True

    # Put the scene's origin somewhere useful: the first marker, else the floor.
    # Across from the first marker (else the floor's middle), height from the floor
    # (else that marker), so a marker tapped on a table still leaves the floor at 0.
    floor = _main_floor(data)
    first = Vector(data["markers"][0]["pose"][:3]) if data.get("markers") else None
    anchor = Vector((0.0, 0.0, 0.0))
    if marker_origin and first is not None:
        anchor.x, anchor.z = first.x, first.z
    elif floor:
        anchor.x, anchor.z = floor["pose"][0], floor["pose"][2]
    if floor_to_zero and floor:
        anchor.y = floor["pose"][1]
    elif first is not None and marker_origin:
        anchor.y = first.y
    # ARCore (x, y, z) lands at Blender (x, -z, y) under the root.
    root.location = (-anchor.x, anchor.z, -anchor.y)
    root["camtrack_floor_y"] = floor["pose"][1] if floor else anchor.y

    for o in context.view_layer.objects:
        o.select_set(False)
    root.select_set(True)
    context.view_layer.objects.active = root
    return root


def _root_of(obj):
    while obj is not None:
        if ROOT_KEY in obj:
            return obj
        obj = obj.parent
    return None


def _active_root(context):
    root = _root_of(context.active_object)
    if root:
        return root
    cam = context.scene.camera
    return _root_of(cam)


def _take_camera(root):
    for c in root.children:
        if c.type == "CAMERA":
            return c
    return None


# ------------------------------------------------------------------ operators

class CAMTRACK_OT_import(bpy.types.Operator, ImportHelper):
    """Import a take from the Camera Tracker phone app (zip or track.json)"""
    bl_idname = "camtrack.import_take"
    bl_label = "Import Camera Tracker take"
    bl_options = {"REGISTER", "UNDO"}

    filter_glob: StringProperty(default="*.zip;*.json", options={"HIDDEN"})
    floor_to_zero: BoolProperty(name="Floor at Z = 0", default=True,
                                description="Move the take so the floor the phone found sits at Z = 0")
    marker_origin: BoolProperty(name="Marker 1 is the origin", default=True,
                                description="Put the first marker you tapped at the world origin")
    point_cloud: BoolProperty(name="Feature points", default=True,
                              description="Add the points the phone tracked, as a reference mesh")
    setup: BoolProperty(name="Set up the scene too", default=True,
                        description="Render settings, shadows, lighting and composite, all in one go")

    def execute(self, context):
        try:
            track = _find_track(self.filepath)
            build_take(context, track, self.floor_to_zero, self.marker_origin, self.point_cloud)
            if self.setup:
                bpy.ops.camtrack.setup()
        except Exception as e:
            self.report({"ERROR"}, str(e))
            return {"CANCELLED"}
        self.report({"INFO"}, "Take imported. Press Numpad 0 to look through the phone")
        return {"FINISHED"}


class CAMTRACK_OT_rekey(bpy.types.Operator):
    """Re-bake the camera with smoothing and a frame offset, from the original track"""
    bl_idname = "camtrack.rekey"
    bl_label = "Apply"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        root = _active_root(context)
        cam = _take_camera(root) if root else None
        if cam is None:
            self.report({"ERROR"}, "Select something from an imported take first")
            return {"CANCELLED"}
        path = bpy.path.abspath(root[ROOT_KEY])
        try:
            data = _load(path)
        except Exception as e:
            self.report({"ERROR"}, f"Can't read the track again: {e}")
            return {"CANCELLED"}
        _key_camera(cam, data, int(cam.get("camtrack_smoothing", 0)), int(cam.get("camtrack_offset", 0)))
        return {"FINISHED"}


class CAMTRACK_OT_shadow_catcher(bpy.types.Operator):
    """Add a shadow catcher on the floor so objects cast shadows onto the real ground"""
    bl_idname = "camtrack.shadow_catcher"
    bl_label = "Add shadow catcher"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        root = _active_root(context)
        if root is None:
            self.report({"ERROR"}, "Select something from an imported take first")
            return {"CANCELLED"}
        data = _load(bpy.path.abspath(root[ROOT_KEY]))
        floor = _main_floor(data)
        size = 6.0
        if floor:
            size = max(4.0, 2.5 * max(floor["extent"]))
            y = floor["pose"][1]
            centre = Vector((floor["pose"][0], y, floor["pose"][2]))
        else:
            y = root.get("camtrack_floor_y", 0.0)
            centre = Vector((0.0, y, 0.0))
        for old in [c for c in root.children if c.name.startswith("Shadow catcher")]:
            bpy.data.objects.remove(old)
        bpy.ops.mesh.primitive_plane_add(size=size)
        plane = context.active_object
        plane.name = "Shadow catcher"
        for c in plane.users_collection:
            c.objects.unlink(plane)
        root.users_collection[0].objects.link(plane)
        plane.parent = root
        # A plane is made flat in XY; in the root's Y up space the floor is XZ.
        plane.matrix_basis = Matrix.Translation(centre) @ Matrix.Rotation(math.radians(-90), 4, "X")
        _make_catcher(plane, _catcher_material(_estimate_lit(context.scene)))
        if context.scene.render.engine not in {"CYCLES", _eevee_id()}:
            context.scene.render.engine = "CYCLES"
        context.scene.render.film_transparent = True
        self.report({"INFO"}, "Shadow catcher added. Use Set up composite to render over the video")
        return {"FINISHED"}


def _compositor_tree(scene):
    """The compositing node tree on 5.x (a node group) and on 4.x (scene.node_tree)."""
    if hasattr(scene, "compositing_node_group"):
        tree = scene.compositing_node_group
        if tree is None:
            tree = bpy.data.node_groups.new("Camera Tracker composite", "CompositorNodeTree")
            scene.compositing_node_group = tree
        return tree, True
    scene.use_nodes = True
    return scene.node_tree, False


class CAMTRACK_OT_composite(bpy.types.Operator):
    """Render the 3D layer over the phone video, with shadows, in one click"""
    bl_idname = "camtrack.composite"
    bl_label = "Set up composite"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene = context.scene
        clip = scene.active_clip
        if clip is None:
            self.report({"ERROR"}, "No video found. Import a take first")
            return {"CANCELLED"}
        scene.render.film_transparent = True
        if scene.render.engine not in {"CYCLES", "BLENDER_EEVEE_NEXT", "BLENDER_EEVEE"}:  # Workbench can't do this
            scene.render.engine = "CYCLES"
        tree, is_group = _compositor_tree(scene)
        tree.nodes.clear()
        rl = tree.nodes.new("CompositorNodeRLayers")
        rl.location = (-300, 200)
        mc = tree.nodes.new("CompositorNodeMovieClip")
        mc.clip = clip
        mc.location = (-300, -150)
        over = tree.nodes.new("CompositorNodeAlphaOver")
        over.location = (50, 50)
        # Background goes in the first image socket, the render on top in the second.
        image_inputs = [s for s in over.inputs if s.type == "RGBA"]
        # Fit the plate to the render size, so a 50% preview render still lines up.
        fit = tree.nodes.new("CompositorNodeScale")
        fit.location = (-120, -150)
        if "Type" in fit.inputs:  # 5.x: options are menu sockets
            try:
                fit.inputs["Type"].default_value = "Render Size"
                fit.inputs["Frame Type"].default_value = "Fit"
            except (TypeError, KeyError):
                pass
        else:
            fit.space = "RENDER_SIZE"
            fit.frame_method = "FIT"
        tree.links.new(mc.outputs["Image"], fit.inputs[0])
        tree.links.new(fit.outputs[0], image_inputs[0])
        tree.links.new(rl.outputs["Image"], image_inputs[1])
        if is_group:
            if not any(s.in_out == "OUTPUT" for s in tree.interface.items_tree if getattr(s, "item_type", "") == "SOCKET"):
                tree.interface.new_socket("Image", in_out="OUTPUT", socket_type="NodeSocketColor")
            out = tree.nodes.new("NodeGroupOutput")
            out.location = (300, 50)
            tree.links.new(over.outputs[0], out.inputs[0])
        else:
            out = tree.nodes.new("CompositorNodeComposite")
            out.location = (300, 50)
            tree.links.new(over.outputs[0], out.inputs[0])
        viewer = tree.nodes.new("CompositorNodeViewer")
        viewer.location = (300, -150)
        tree.links.new(over.outputs[0], viewer.inputs[0])
        self.report({"INFO"}, "Composite ready. F12 renders your objects over the video")
        return {"FINISHED"}


class CAMTRACK_OT_match_light(bpy.types.Operator):
    """Add a sun pointing the way the real main light came from, as the phone measured it"""
    bl_idname = "camtrack.match_light"
    bl_label = "Match the real light"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        root = _active_root(context)
        if root is None:
            self.report({"ERROR"}, "Select something from an imported take first")
            return {"CANCELLED"}
        data = _load(bpy.path.abspath(root[ROOT_KEY]))
        light = data.get("light")
        if not light:
            self.report({"WARNING"}, "This phone did not measure the light for this take")
            return {"CANCELLED"}
        d = Vector(light["direction"]).normalized()
        c = Vector(light["intensity"])
        peak = max(c.x, c.y, c.z, 1e-4)
        for old in [c for c in root.children if c.name.startswith("Real light")]:
            bpy.data.objects.remove(old)
        sun_data = bpy.data.lights.new("Real light", "SUN")
        sun_data.color = (c.x / peak, c.y / peak, c.z / peak)
        sun_data.energy = max(0.5, min(10.0, peak * 3.0))
        sun_data.angle = math.radians(8)
        sun = bpy.data.objects.new("Real light", sun_data)
        root.users_collection[0].objects.link(sun)
        sun.parent = root
        # A sun shines down its -Z; ARCore's direction points towards the light.
        sun.matrix_basis = d.to_track_quat("Z", "Y").to_matrix().to_4x4()
        sun.location = Vector((0, 1.5, 0))

        sh = light.get("harmonics")
        if sh and len(sh) >= 3:
            world = context.scene.world or bpy.data.worlds.new("World")
            context.scene.world = world
            ambient = [max(0.0, v * 0.886) for v in sh[:3]]
            if hasattr(world, "use_nodes"):
                world.use_nodes = True
            bg = next((n for n in world.node_tree.nodes if n.type == "BACKGROUND"), None) if world.node_tree else None
            if bg:
                bg.inputs["Color"].default_value = (*ambient, 1.0)
                bg.inputs["Strength"].default_value = 1.0
            else:
                world.color = ambient
        self.report({"INFO"}, "Sun added from the light the phone saw")
        return {"FINISHED"}


class CAMTRACK_OT_to_marker(bpy.types.Operator):
    """Stand the selected objects on a marker you tapped on the phone"""
    bl_idname = "camtrack.to_marker"
    bl_label = "Put selection on marker"
    bl_options = {"REGISTER", "UNDO"}

    marker: StringProperty()

    def execute(self, context):
        target = bpy.data.objects.get(self.marker)
        if target is None:
            return {"CANCELLED"}
        spot = target.matrix_world.translation.copy()
        moved = 0
        for o in context.selected_objects:
            if o == target or _root_of(o) is not None:
                continue
            o.location = spot if o.parent is None else o.parent.matrix_world.inverted() @ spot
            moved += 1
        if moved == 0:
            self.report({"WARNING"}, "Select your own objects first, then pick the marker")
        return {"FINISHED"}


class CAMTRACK_OT_room_light(bpy.types.Operator):
    """Light the scene with the rough HDR the phone painted of the room"""
    bl_idname = "camtrack.room_light"
    bl_label = "Light with the room (HDR)"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        root = _active_root(context)
        if root is None:
            self.report({"ERROR"}, "Select something from an imported take first")
            return {"CANCELLED"}
        track = bpy.path.abspath(root[ROOT_KEY])
        data = _load(track)
        room = data.get("room") or {}
        hdr = os.path.join(os.path.dirname(track), room.get("hdr", "env.hdr"))
        if not os.path.exists(hdr):
            self.report({"WARNING"}, "This shot has no room HDR. Record it again with app 1.0.1 or newer")
            return {"CANCELLED"}
        scene = context.scene
        world = bpy.data.worlds.new(root.name.replace(" origin", "") + " room")
        scene.world = world
        if hasattr(world, "use_nodes"):
            world.use_nodes = True
        nt = world.node_tree
        bg = next(n for n in nt.nodes if n.type == "BACKGROUND")
        env = nt.nodes.new("ShaderNodeTexEnvironment")
        env.image = bpy.data.images.load(hdr, check_existing=True)
        env.location = (-300, 300)
        # The HDR is laid out for an unturned take; follow the take if it was spun round Z.
        coord = nt.nodes.new("ShaderNodeTexCoord")
        coord.location = (-700, 300)
        mapping = nt.nodes.new("ShaderNodeMapping")
        mapping.location = (-500, 300)
        # App 1.0.1 laid the HDR out half a turn round from Blender's convention.
        half_turn = 0.0 if room.get("layout") == "blender" else math.pi
        mapping.inputs["Rotation"].default_value[2] = half_turn - root.rotation_euler[2]
        nt.links.new(coord.outputs["Generated"], mapping.inputs["Vector"])
        nt.links.new(mapping.outputs["Vector"], env.inputs["Vector"])
        nt.links.new(env.outputs["Color"], bg.inputs["Color"])
        bg.inputs["Strength"].default_value = 1.0
        # The HDR already holds the main light, so a matched sun would light things twice.
        for c in root.children:
            if c.type == "LIGHT" and c.name.startswith("Real light"):
                c.hide_render = True
                c.hide_viewport = True
        pct = int(round(100 * float(room.get("coverage", 0))))
        self.report({"INFO"}, f"Room lighting on. The phone saw {pct}% of the room, the rest is estimated")
        return {"FINISHED"}


def _quat_mat(q):
    """[qx, qy, qz, qw] to a 3x3 numpy rotation."""
    import numpy as np
    x, y, z, w = q
    return np.array([
        [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
        [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
        [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
    ])


def _room_points(folder, data, stride=2, voxel=0.015):
    """Depth maps lifted into ARCore's world, coloured from the snapshots, thinned on a voxel grid."""
    import numpy as np
    depth_rows = data.get("depth") or []
    keys = (data.get("room") or {}).get("keyframes") or []
    snaps = []
    for i, k in enumerate(keys):
        path = os.path.join(folder, "room", "c_%03d.jpg" % i)
        if not os.path.exists(path):
            continue
        img = bpy.data.images.load(path, check_existing=False)
        w, h = img.size
        px = np.empty(w * h * 4, np.float32)
        img.pixels.foreach_get(px)
        bpy.data.images.remove(img)
        # Blender keeps rows bottom up; flip so row 0 is the top like the camera.
        px = px.reshape(h, w, 4)[::-1, :, :3]
        snaps.append((k[0], w, h, np.array(k[3:6]), _quat_mat(k[6:10]), k[10:14], px))

    pts, cols = [], []
    for n, row in enumerate(depth_rows):
        path = os.path.join(folder, "room", "d_%03d.bin" % n)
        if not os.path.exists(path):
            continue
        frame, w, h = int(row[0]), int(row[1]), int(row[2])
        t = np.array(row[3:6])
        R = _quat_mat(row[6:10])
        fx, fy, cx, cy = row[10:14]
        d = np.fromfile(path, dtype="<u2").reshape(h, w)[::stride, ::stride].astype(np.float32) / 1000.0
        vv, uu = np.mgrid[0:h:stride, 0:w:stride].astype(np.float32)
        ok = (d > 0.15) & (d < 6.0)
        z = d[ok]
        cam = np.stack([(uu[ok] + 0.5 - cx) / fx * z, -(vv[ok] + 0.5 - cy) / fy * z, -z], -1)
        world = cam @ R.T + t
        col = np.full((len(world), 3), 0.6, np.float32)
        if snaps:
            s = min(snaps, key=lambda s: abs(s[0] - frame))
            _, sw, sh, st, sR, (sfx, sfy, scx, scy), spx = s
            c = (world - st) @ sR
            front = -c[:, 2] > 0.05
            zz = np.where(front, -c[:, 2], 1.0)
            su = scx + sfx * c[:, 0] / zz
            sv = scy - sfy * c[:, 1] / zz
            inside = front & (su >= 0) & (sv >= 0) & (su < sw) & (sv < sh)
            col[inside] = spx[sv[inside].astype(int), su[inside].astype(int)]
        pts.append(world)
        cols.append(col)
    if not pts:
        return None, None
    P = np.concatenate(pts)
    C = np.concatenate(cols)
    # One point per voxel, averaged, so overlapping frames don't pile up.
    key = np.floor(P / voxel).astype(np.int64)
    _, inv, counts = np.unique(key, axis=0, return_inverse=True, return_counts=True)
    inv = inv.reshape(-1)
    out_p = np.zeros((len(counts), 3))
    out_c = np.zeros((len(counts), 3))
    np.add.at(out_p, inv, P)
    np.add.at(out_c, inv, C)
    out_p /= counts[:, None]
    out_c /= counts[:, None]
    # Lone voxels are mostly depth noise.
    keep = counts >= 2
    return out_p[keep], out_c[keep]


def _set_menu(node, name, value, prop, prop_value):
    """5.x exposes node options as menu sockets, 4.x as properties."""
    if name in node.inputs and node.inputs[name].type == "MENU":
        node.inputs[name].default_value = value
    elif hasattr(node, prop):
        setattr(node, prop, prop_value)


def _room_nodes(voxel):
    ng = bpy.data.node_groups.new("Camera Tracker room mesh", "GeometryNodeTree")
    ng.interface.new_socket("Geometry", in_out="INPUT", socket_type="NodeSocketGeometry")
    ng.interface.new_socket("Geometry", in_out="OUTPUT", socket_type="NodeSocketGeometry")
    sock = ng.interface.new_socket("Thickness", in_out="INPUT", socket_type="NodeSocketFloat")
    sock.default_value = voxel * 1.5
    sock.min_value = 0.005
    N = ng.nodes
    L = ng.links
    gin = N.new("NodeGroupInput")
    gout = N.new("NodeGroupOutput")
    m2p = N.new("GeometryNodeMeshToPoints")
    p2v = N.new("GeometryNodePointsToVolume")
    _set_menu(p2v, "Resolution Mode", "Size", "resolution_mode", "VOXEL_SIZE")
    p2v.inputs["Voxel Size"].default_value = voxel
    v2m = N.new("GeometryNodeVolumeToMesh")
    _set_menu(v2m, "Resolution Mode", "Grid", "resolution_mode", "GRID")
    v2m.inputs["Threshold"].default_value = 0.3
    pos = N.new("GeometryNodeInputPosition")
    near = N.new("GeometryNodeSampleNearest")
    attr = N.new("GeometryNodeInputNamedAttribute")
    attr.data_type = "FLOAT_COLOR"
    attr.inputs["Name"].default_value = "Col"
    samp = N.new("GeometryNodeSampleIndex")
    samp.data_type = "FLOAT_COLOR"
    store = N.new("GeometryNodeStoreNamedAttribute")
    store.data_type = "FLOAT_COLOR"
    store.inputs["Name"].default_value = "Col"
    setmat = N.new("GeometryNodeSetMaterial")

    L.new(gin.outputs[0], m2p.inputs["Mesh"])
    L.new(m2p.outputs["Points"], p2v.inputs["Points"])
    L.new(gin.outputs[1], p2v.inputs["Radius"])
    L.new(p2v.outputs[0], v2m.inputs["Volume"])
    L.new(gin.outputs[0], near.inputs["Geometry"])
    L.new(pos.outputs["Position"], near.inputs["Sample Position"])
    L.new(gin.outputs[0], samp.inputs["Geometry"])
    L.new(attr.outputs[0], samp.inputs["Value"])
    L.new(near.outputs["Index"], samp.inputs["Index"])
    # The volume wraps every point in a ball, so its surface floats one radius above
    # the real one. Pull it back in along the normals onto the measured depth.
    shrink = N.new("GeometryNodeSetPosition")
    normal = N.new("GeometryNodeInputNormal")
    scale = N.new("ShaderNodeVectorMath")
    scale.operation = "SCALE"
    neg = N.new("ShaderNodeMath")
    neg.operation = "MULTIPLY"
    neg.inputs[1].default_value = -0.9
    L.new(gin.outputs[1], neg.inputs[0])
    L.new(normal.outputs["Normal"], scale.inputs[0])
    L.new(neg.outputs[0], scale.inputs["Scale"])
    L.new(v2m.outputs["Mesh"], shrink.inputs["Geometry"])
    L.new(scale.outputs["Vector"], shrink.inputs["Offset"])
    shrink.location = (700, 200)
    normal.location = (300, 380)
    scale.location = (480, 380)
    neg.location = (300, 520)
    L.new(shrink.outputs["Geometry"], store.inputs["Geometry"])
    L.new(samp.outputs[0], store.inputs["Value"])
    L.new(store.outputs[0], setmat.inputs["Geometry"])
    L.new(setmat.outputs[0], gout.inputs[0])
    for i, n in enumerate([gin, m2p, p2v, v2m, store, setmat, gout]):
        n.location = (i * 220, 0)
    for i, n in enumerate([pos, attr, near, samp]):
        n.location = (440 + i * 200, -260)
    return ng, setmat


class CAMTRACK_OT_room_mesh(bpy.types.Operator):
    """Build a rough coloured mesh of the room from the phone's depth, for shadows, occlusion and reflections"""
    bl_idname = "camtrack.room_mesh"
    bl_label = "Build room mesh"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        root = _active_root(context)
        if root is None:
            self.report({"ERROR"}, "Select something from an imported take first")
            return {"CANCELLED"}
        track = bpy.path.abspath(root[ROOT_KEY])
        data = _load(track)
        if not data.get("depth"):
            self.report({"WARNING"}, "This shot has no depth. The phone may not support ARCore depth")
            return {"CANCELLED"}
        for old in [c for c in root.children if c.name.endswith(" room")]:
            bpy.data.objects.remove(old)
        voxel = 0.02
        P, C = _room_points(os.path.dirname(track), data, voxel=voxel)
        if P is None or len(P) == 0:
            self.report({"ERROR"}, "No usable depth in this shot")
            return {"CANCELLED"}

        name = root.name.replace(" origin", "") + " room"
        mesh = bpy.data.meshes.new(name)
        mesh.vertices.add(len(P))
        mesh.vertices.foreach_set("co", P.astype("float32").ravel())
        col = mesh.color_attributes.new("Col", "FLOAT_COLOR", "POINT")
        import numpy as np
        rgba = np.concatenate([C, np.ones((len(C), 1))], 1).astype("float32")
        col.data.foreach_set("color", rgba.ravel())
        mesh.update()
        obj = bpy.data.objects.new(name, mesh)
        root.users_collection[0].objects.link(obj)
        obj.parent = root

        mat = bpy.data.materials.new(name)
        mat.use_nodes = True
        nt = mat.node_tree
        bsdf = nt.nodes["Principled BSDF"]
        a = nt.nodes.new("ShaderNodeAttribute")
        a.attribute_name = "Col"
        a.location = (-300, 200)
        nt.links.new(a.outputs["Color"], bsdf.inputs["Base Color"])
        bsdf.inputs["Roughness"].default_value = 0.85

        ng, setmat = _room_nodes(voxel)
        setmat.inputs["Material"].default_value = mat
        mod = obj.modifiers.new("Room mesh", "NODES")
        mod.node_group = ng
        # Seen only through what it does to your objects: shadows land on it and it hides what is behind it.
        _make_catcher(obj, _catcher_material(_estimate_lit(context.scene)))
        if context.scene.render.engine not in {"CYCLES", _eevee_id()}:
            context.scene.render.engine = "CYCLES"
        context.scene.render.film_transparent = True
        self.report({"INFO"}, f"Room mesh from {len(data['depth'])} depth frames. It catches shadows and hides objects behind real things")
        return {"FINISHED"}


class CAMTRACK_OT_setup(bpy.types.Operator):
    """Set up everything for this shot: resolution, frame rate, camera, render settings, shadows, lighting and the composite"""
    bl_idname = "camtrack.setup"
    bl_label = "Set up scene"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        root = _active_root(context)
        cam = _take_camera(root) if root else None
        if cam is None:
            self.report({"ERROR"}, "Import a take first")
            return {"CANCELLED"}
        track = bpy.path.abspath(root[ROOT_KEY])
        data = _load(track)
        folder = os.path.dirname(track)
        scene = context.scene
        name = root.name.replace(" origin", "")

        # The shot's own size, rate and length.
        scene.render.resolution_x = data["width"]
        scene.render.resolution_y = data["height"]
        scene.render.resolution_percentage = 100
        scene.render.pixel_aspect_x = scene.render.pixel_aspect_y = 1
        scene.render.fps = int(data["fps"])
        scene.render.fps_base = 1.0
        offset = int(cam.get("camtrack_offset", 0))
        scene.frame_start = 1 + offset
        scene.frame_end = len(data["frames"]) + offset
        scene.frame_set(scene.frame_start)
        scene.camera = cam

        # Render: Cycles with a clean plate. Standard view keeps the video's colours as filmed.
        if scene.render.engine != _eevee_id():
            scene.render.engine = "CYCLES"
        scene.cycles.samples = 128
        scene.cycles.use_denoising = True
        scene.render.film_transparent = True
        try:
            scene.view_settings.view_transform = "Standard"
            scene.view_settings.look = "None"
        except TypeError:
            pass

        # Motion blur so CG moves smear like the filmed picture does. A 180 degree
        # shutter (half a frame) is what phones roughly give in normal light.
        scene.render.use_motion_blur = True
        scene.render.motion_blur_shutter = 0.5

        done = []
        # Shadows: the room mesh when the phone had depth, else a floor catcher.
        has_mesh = any(c.name.endswith(" room") for c in root.children)
        if data.get("depth") and not has_mesh:
            if "FINISHED" in bpy.ops.camtrack.room_mesh():
                has_mesh = True
                done.append("room mesh")
        if not has_mesh:
            bpy.ops.camtrack.shadow_catcher()
            done.append("shadow catcher")
        else:
            for old in [c for c in root.children if c.name.startswith("Shadow catcher")]:
                bpy.data.objects.remove(old)

        # Light: the room HDR when there is one, else a sun from the measured light.
        hdr = os.path.join(folder, (data.get("room") or {}).get("hdr", "env.hdr"))
        if os.path.exists(hdr) and "FINISHED" in bpy.ops.camtrack.room_light():
            done.append("room lighting")
        elif data.get("light") and "FINISHED" in bpy.ops.camtrack.match_light():
            done.append("sun from the real light")

        bpy.ops.camtrack.composite()
        done.append("composite")
        if bpy.data.materials.get(CATCHER_MAT):
            _catcher_material(_estimate_lit(scene))

        # Output: an image sequence next to the .blend, or next to the shot if unsaved.
        base = "//render/" if bpy.data.filepath else os.path.join(folder, "render") + os.sep
        scene.render.filepath = base + name + "_"
        scene.render.image_settings.file_format = "PNG"

        # Look through the phone with the sidebar open, like after import.
        for window in context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == "VIEW_3D":
                    space = area.spaces.active
                    space.region_3d.view_perspective = "CAMERA"
                    space.show_region_ui = True
        self.report({"INFO"}, "Ready: " + ", ".join(done) + ". Add your objects, then F12 or Render Animation")
        return {"FINISHED"}


CATCHER_MAT = "Shadow catcher (Cycles + EEVEE)"


def _eevee_id():
    items = [e.identifier for e in bpy.types.RenderSettings.bl_rna.properties["engine"].enum_items]
    return "BLENDER_EEVEE_NEXT" if "BLENDER_EEVEE_NEXT" in items else "BLENDER_EEVEE"


def _estimate_lit(scene):
    """Roughly how bright a white floor would be with nothing shadowing it, so the
    EEVEE catcher knows what "no shadow" looks like."""
    lit = 0.0
    up = Vector((0, 0, 1))
    for o in scene.objects:
        if o.type == "LIGHT" and o.data.type == "SUN" and not o.hide_render:
            towards = (o.matrix_world.to_3x3() @ Vector((0, 0, 1))).normalized()
            # A white diffuse floor under a sun of strength E shows E * cos / pi.
            lit += o.data.energy * max(0.0, towards.dot(up)) / math.pi
    world = scene.world
    if world and world.node_tree:
        bg = next((n for n in world.node_tree.nodes if n.type == "BACKGROUND"), None)
        env = next((n for n in world.node_tree.nodes if n.type == "TEX_ENVIRONMENT"), None)
        strength = bg.inputs["Strength"].default_value if bg else 1.0
        if env and env.image:
            img = env.image
            w, h = img.size
            if w and h:
                import numpy as np
                px = np.empty(w * h * 4, np.float32)
                img.pixels.foreach_get(px)
                px = px.reshape(h, w, 4)[..., :3].mean(-1)
                # Light reaching a floor: the upper half, weighted by how high it is.
                rows = np.arange(h)
                el = (rows + 0.5) / h * math.pi - math.pi / 2  # bottom row first in Blender
                wgt = np.clip(np.sin(el), 0, None) * np.cos(el)
                lit += float((px.mean(1) * wgt).sum() / max(wgt.sum(), 1e-6)) * 2.0 * strength
        elif bg:
            c = bg.inputs["Color"].default_value
            lit += (c[0] + c[1] + c[2]) / 3.0 * strength
    return max(0.05, lit)


def _catcher_material(lit):
    """One material, two outputs: Cycles draws a plain white surface (its own shadow
    catcher does the work); EEVEE gets a shadow only surface: see through where lit,
    black where shadowed, and a holdout so it hides objects behind it."""
    mat = bpy.data.materials.get(CATCHER_MAT)
    if mat is None:
        mat = bpy.data.materials.new(CATCHER_MAT)
        mat.use_nodes = True
        nt = mat.node_tree
        nt.nodes.clear()
        N, L = nt.nodes, nt.links
        out_c = N.new("ShaderNodeOutputMaterial"); out_c.target = "CYCLES"; out_c.location = (900, 250)
        out_e = N.new("ShaderNodeOutputMaterial"); out_e.target = "EEVEE"; out_e.location = (900, -50)
        white = N.new("ShaderNodeBsdfDiffuse"); white.location = (600, 300)
        L.new(white.outputs[0], out_c.inputs["Surface"])

        probe = N.new("ShaderNodeBsdfDiffuse"); probe.location = (-600, 0)
        to_rgb = N.new("ShaderNodeShaderToRGB"); to_rgb.location = (-400, 0)
        bw = N.new("ShaderNodeRGBToBW"); bw.location = (-220, 0)
        lit_v = N.new("ShaderNodeValue"); lit_v.name = lit_v.label = "Lit level"; lit_v.location = (-220, -150)
        div = N.new("ShaderNodeMath"); div.operation = "DIVIDE"; div.use_clamp = True; div.location = (-40, 0)
        inv = N.new("ShaderNodeMath"); inv.operation = "SUBTRACT"; inv.inputs[0].default_value = 1.0; inv.use_clamp = True; inv.location = (140, 0)
        str_v = N.new("ShaderNodeValue"); str_v.name = str_v.label = "Shadow strength"; str_v.outputs[0].default_value = 1.0; str_v.location = (140, -150)
        mul = N.new("ShaderNodeMath"); mul.operation = "MULTIPLY"; mul.use_clamp = True; mul.location = (320, 0)
        hold = N.new("ShaderNodeHoldout"); hold.location = (500, 100)
        black = N.new("ShaderNodeEmission"); black.inputs["Color"].default_value = (0, 0, 0, 1); black.location = (500, -120)
        mix = N.new("ShaderNodeMixShader"); mix.location = (700, -50)
        L.new(probe.outputs[0], to_rgb.inputs[0])
        L.new(to_rgb.outputs["Color"], bw.inputs[0])
        L.new(bw.outputs[0], div.inputs[0])
        # 25% dead zone: the estimate runs a little high, and lit floor must stay exactly as filmed.
        scale = N.new("ShaderNodeMath"); scale.operation = "MULTIPLY"; scale.inputs[1].default_value = 0.75; scale.location = (-40, -150)
        L.new(lit_v.outputs[0], scale.inputs[0])
        L.new(scale.outputs[0], div.inputs[1])
        L.new(div.outputs[0], inv.inputs[1])
        L.new(inv.outputs[0], mul.inputs[0])
        L.new(str_v.outputs[0], mul.inputs[1])
        L.new(mul.outputs[0], mix.inputs["Fac"])
        L.new(hold.outputs[0], mix.inputs[1])
        L.new(black.outputs[0], mix.inputs[2])
        L.new(mix.outputs[0], out_e.inputs["Surface"])
        mat.diffuse_color = (0.85, 0.85, 0.85, 0.35)
    mat.node_tree.nodes["Lit level"].outputs[0].default_value = lit
    return mat


def _make_catcher(obj, mat):
    obj.is_shadow_catcher = True
    if obj.type != "MESH":
        return
    for m in obj.modifiers:
        if m.type == "NODES" and m.node_group:
            for n in m.node_group.nodes:
                if n.bl_idname == "GeometryNodeSetMaterial":
                    n.inputs["Material"].default_value = mat
    obj.data.materials.clear()
    obj.data.materials.append(mat)


class CAMTRACK_OT_make_catcher(bpy.types.Operator):
    """Turn the selected objects into shadow catchers that work in both Cycles and EEVEE"""
    bl_idname = "camtrack.make_catcher"
    bl_label = "Make selected a shadow catcher"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        objs = [o for o in context.selected_objects if o.type == "MESH"]
        if not objs:
            self.report({"WARNING"}, "Select one or more meshes first")
            return {"CANCELLED"}
        mat = _catcher_material(_estimate_lit(context.scene))
        for o in objs:
            _make_catcher(o, mat)
        context.scene.render.film_transparent = True
        self.report({"INFO"}, f"{len(objs)} shadow catcher{'s' if len(objs) > 1 else ''}, for Cycles and EEVEE")
        return {"FINISHED"}


class CAMTRACK_OT_engine(bpy.types.Operator):
    """Switch the render engine, keeping the shadow catchers working"""
    bl_idname = "camtrack.engine"
    bl_label = "Render engine"
    bl_options = {"REGISTER", "UNDO"}

    engine: StringProperty()

    def execute(self, context):
        scene = context.scene
        if self.engine == "EEVEE":  # noqa
            scene.render.engine = _eevee_id()
            ee = scene.eevee
            # Ray traced indirect light gives the soft darkening around objects that
            # Cycles' catcher has, and softer, longer sun shadows.
            for prop, value in (("use_raytracing", True), ("use_fast_gi", True), ("use_shadows", True),
                                ("shadow_ray_count", 2), ("shadow_step_count", 8), ("taa_render_samples", 64)):
                if hasattr(ee, prop):
                    setattr(ee, prop, value)
            if scene.world and hasattr(scene.world, "sun_threshold"):
                # Lets EEVEE pull a shadow casting sun out of the room HDR.
                scene.world.sun_threshold = 2.0
        else:
            scene.render.engine = "CYCLES"
        scene.render.film_transparent = True
        mat = bpy.data.materials.get(CATCHER_MAT)
        if mat:
            _catcher_material(_estimate_lit(scene))
        return {"FINISHED"}


def _projection_material(name, projector, image, frame, total, follow, w, h, lens_obj):
    """Camera projection in the shader (the Ian Hubert trick): each point is looked
    up in the video through the projector camera's own lens, so no UVs are needed and
    it works on generated meshes too."""
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    N, L = nt.nodes, nt.links
    cam = lens_obj.data
    big = float(max(w, h))
    k = cam.lens / cam.sensor_width  # focal length over the long side of the frame
    # Factors that turn x / -z and y / -z into 0..1 image coordinates.
    ku, kv = k * big / w, k * big / h
    su, sv = cam.shift_x * big / w, cam.shift_y * big / h

    tc = N.new("ShaderNodeTexCoord"); tc.object = projector; tc.location = (-1100, 0)
    sep = N.new("ShaderNodeSeparateXYZ"); sep.location = (-900, 0)
    negz = N.new("ShaderNodeMath"); negz.operation = "MULTIPLY"; negz.inputs[1].default_value = -1.0; negz.location = (-700, -200)
    dx = N.new("ShaderNodeMath"); dx.operation = "DIVIDE"; dx.location = (-520, 100)
    dy = N.new("ShaderNodeMath"); dy.operation = "DIVIDE"; dy.location = (-520, -60)
    u = N.new("ShaderNodeMath"); u.operation = "MULTIPLY_ADD"; u.inputs[1].default_value = ku; u.inputs[2].default_value = 0.5 - su; u.location = (-340, 100)
    v = N.new("ShaderNodeMath"); v.operation = "MULTIPLY_ADD"; v.inputs[1].default_value = kv; v.inputs[2].default_value = 0.5 - sv; v.location = (-340, -60)
    comb = N.new("ShaderNodeCombineXYZ"); comb.location = (-160, 0)
    tex = N.new("ShaderNodeTexImage"); tex.image = image; tex.extension = "CLIP"; tex.location = (20, 0)
    iu = tex.image_user
    iu.frame_start = 1
    iu.use_cyclic = False
    if follow:
        iu.frame_duration = total
        iu.frame_offset = 0
        iu.use_auto_refresh = True
    else:
        iu.frame_duration = 1
        iu.frame_offset = frame - 1
        iu.use_auto_refresh = True
    emit = N.new("ShaderNodeEmission"); emit.location = (320, 0)
    out = N.new("ShaderNodeOutputMaterial"); out.location = (520, 0)
    L.new(tc.outputs["Object"], sep.inputs[0])
    L.new(sep.outputs["Z"], negz.inputs[0])
    L.new(sep.outputs["X"], dx.inputs[0]); L.new(negz.outputs[0], dx.inputs[1])
    L.new(sep.outputs["Y"], dy.inputs[0]); L.new(negz.outputs[0], dy.inputs[1])
    L.new(dx.outputs[0], u.inputs[0]); L.new(dy.outputs[0], v.inputs[0])
    L.new(u.outputs[0], comb.inputs["X"]); L.new(v.outputs[0], comb.inputs["Y"])
    L.new(comb.outputs[0], tex.inputs["Vector"])
    # Emission keeps the filmed pixels exactly as filmed.
    L.new(tex.outputs["Color"], emit.inputs["Color"])
    L.new(emit.outputs[0], out.inputs["Surface"])
    return mat


class CAMTRACK_OT_project(bpy.types.Operator):
    """Paint the video onto the selected objects from the phone's view (camera projection), so they can be moved, broken or extruded with the real texture"""
    bl_idname = "camtrack.project"
    bl_label = "Project the video onto selected"
    bl_options = {"REGISTER", "UNDO"}

    follow: BoolProperty(name="Follow the video", default=False,
                         description="Re-project every frame from the moving camera (good for reflections). Off freezes the current frame onto the objects")

    def execute(self, context):
        root = _active_root(context)
        if root is None:
            root = _root_of(context.scene.camera)
        cam = _take_camera(root) if root else None
        objs = [o for o in context.selected_objects if o.type == "MESH"]
        if cam is None or not objs:
            self.report({"ERROR"}, "Select the meshes to paint, with a take imported")
            return {"CANCELLED"}
        track = bpy.path.abspath(root[ROOT_KEY])
        data = _load(track)
        video = os.path.join(os.path.dirname(track), data.get("video", "shot.mp4"))
        img = bpy.data.images.load(video, check_existing=True)
        img.source = "MOVIE"
        scene = context.scene
        frame = scene.frame_current
        w, h = data["width"], data["height"]
        if self.follow:
            projector = cam
            name = "Projected video (follows)"
        else:
            # A still copy of the phone camera, frozen where it was on this frame.
            pdata = cam.data.copy()
            pdata.animation_data_clear()
            pdata.show_background_images = False
            projector = bpy.data.objects.new(f"Projector f{frame}", pdata)
            root.users_collection[0].objects.link(projector)
            projector.matrix_world = cam.matrix_world.copy()
            projector.hide_render = True
            name = f"Projected frame {frame}"
        mat = _projection_material(name, projector, img, frame, len(data["frames"]), self.follow, w, h, projector)
        for o in objs:
            o.is_shadow_catcher = False
            for m in o.modifiers:
                if m.type == "NODES" and m.node_group:
                    for n in m.node_group.nodes:
                        if n.bl_idname == "GeometryNodeSetMaterial":
                            n.inputs["Material"].default_value = mat
            o.data.materials.clear()
            o.data.materials.append(mat)
        self.report({"INFO"}, f"Projected frame {frame} onto {len(objs)} object{'s' if len(objs) > 1 else ''}" if not self.follow
                    else f"The moving video now projects onto {len(objs)} object{'s' if len(objs) > 1 else ''}")
        return {"FINISHED"}


# ---------------------------------------------------------------------- panel

class CAMTRACK_PT_panel(bpy.types.Panel):
    bl_label = "Camera Tracker"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tracker"

    def draw(self, context):
        layout = self.layout
        layout.operator(CAMTRACK_OT_import.bl_idname, text="Import take", icon="IMPORT")
        root = _active_root(context)
        if root is None:
            layout.label(text="Pick the zip from the phone app", icon="INFO")
            return
        cam = _take_camera(root)
        row = layout.row()
        row.scale_y = 1.5
        row.operator(CAMTRACK_OT_setup.bl_idname, text="Set up scene", icon="SCENE_DATA")
        row = layout.row(align=True)
        eevee = context.scene.render.engine == _eevee_id()
        op = row.operator(CAMTRACK_OT_engine.bl_idname, text="Cycles", depress=not eevee)
        op.engine = "CYCLES"
        op = row.operator(CAMTRACK_OT_engine.bl_idname, text="EEVEE", depress=eevee)
        op.engine = "EEVEE"
        box = layout.box()
        box.label(text=root.name.replace(" origin", ""), icon="CAMERA_DATA")
        box.prop(root, "location", text="Move take")
        box.prop(root, "scale", text="Scale take")
        if cam is not None:
            col = box.column(align=True)
            col.prop(cam, '["camtrack_smoothing"]', text="Smooth shake (frames)")
            col.prop(cam, '["camtrack_offset"]', text="Frame offset")
            col.operator(CAMTRACK_OT_rekey.bl_idname, text="Apply smoothing and offset")

        box = layout.box()
        box.label(text="Make it look real", icon="SHADING_RENDERED")
        box.operator(CAMTRACK_OT_shadow_catcher.bl_idname, icon="MESH_PLANE")
        box.operator(CAMTRACK_OT_make_catcher.bl_idname, icon="RESTRICT_SELECT_OFF")
        row = box.row(align=True)
        op = row.operator(CAMTRACK_OT_project.bl_idname, text="Project frame onto selected", icon="IMAGE_PLANE")
        op.follow = False
        op = row.operator(CAMTRACK_OT_project.bl_idname, text="", icon="FILE_MOVIE")
        op.follow = True
        mat = bpy.data.materials.get(CATCHER_MAT)
        if mat and context.scene.render.engine == _eevee_id():
            col = box.column(align=True)
            col.prop(mat.node_tree.nodes["Lit level"].outputs[0], "default_value", text="EEVEE lit level")
            col.prop(mat.node_tree.nodes["Shadow strength"].outputs[0], "default_value", text="EEVEE shadow strength")
        box.operator(CAMTRACK_OT_room_light.bl_idname, icon="WORLD")
        box.operator(CAMTRACK_OT_match_light.bl_idname, icon="LIGHT_SUN")
        box.operator(CAMTRACK_OT_room_mesh.bl_idname, icon="MESH_ICOSPHERE")
        box.operator(CAMTRACK_OT_composite.bl_idname, icon="NODE_COMPOSITING")

        markers = [c for c in root.children if c.type == "EMPTY" and c.name.startswith("Marker")]
        if markers:
            box = layout.box()
            box.label(text="Stand selected objects on", icon="EMPTY_AXIS")
            row = box.row(align=True)
            for m in markers[:8]:
                op = row.operator(CAMTRACK_OT_to_marker.bl_idname, text=m.name.replace("Marker ", "M"))
                op.marker = m.name


def _menu_import(self, context):
    self.layout.operator(CAMTRACK_OT_import.bl_idname, text="Camera Tracker take (.zip, .json)")


classes = (
    CAMTRACK_OT_import,
    CAMTRACK_OT_rekey,
    CAMTRACK_OT_shadow_catcher,
    CAMTRACK_OT_composite,
    CAMTRACK_OT_match_light,
    CAMTRACK_OT_to_marker,
    CAMTRACK_OT_room_light,
    CAMTRACK_OT_room_mesh,
    CAMTRACK_OT_setup,
    CAMTRACK_OT_make_catcher,
    CAMTRACK_OT_engine,
    CAMTRACK_OT_project,
    CAMTRACK_PT_panel,
)


def register():
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.TOPBAR_MT_file_import.append(_menu_import)


def unregister():
    bpy.types.TOPBAR_MT_file_import.remove(_menu_import)
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
